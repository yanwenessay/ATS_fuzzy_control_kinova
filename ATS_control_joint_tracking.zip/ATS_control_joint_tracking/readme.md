kinova@kinova-Precision-3660:~/workspace/Kinova-kortex2_Gen3_G3L/api_python/examples/ATS_control$ python3 impedance_control.py 
Logging as admin on device 192.168.1.10
Logging as admin on device 192.168.1.10
✅ 7自由度笛卡尔阻抗控制器初始化完成

============================================================
🤖 7自由度笛卡尔阻抗控制器
============================================================
算法流程:
1. 外环阻抗模型: F_ref = -(K_d*e + B_d*e_dot + M_d*e_ddot)
2. 内环力矩映射: τ_task = J_em^T * F_c
3. 零空间控制: τ_null = N^T * (K_p*(q_null - q) - K_d*q_dot)
4. 重力补偿: τ_gravity = G(q)
5. 总控制律: τ = τ_task + τ_null + τ_gravity
============================================================
控制参数:
- 阻抗参数: K_d=[200. 200. 200.], B_d=[15. 15. 15.]
- 控制频率: 1000 Hz
- 运行时长: 120 秒
- 轨迹设置: 初始位姿保持, 速度=0, 加速度=0
- 自定义初始位置: [180, 16, 180, 229, 0, 54, 90] 度
============================================================
🚀 移动到预设位置...
移动到预设位置失败: Server error name=ERROR_DEVICE, sub name=ROBOT_IN_FAULT => Failed to execute action: Command failed arm is in fault state 

🔧 初始化力矩控制模式...
✅ 力矩控制模式初始化完成
🚀 启动笛卡尔阻抗控制...
✅ 阻抗控制已启动

⌨️ 按Enter停止控制...
设置期望轨迹为初始位姿: [-2.00751414e-01 -5.90831224e-03  3.16621793e-01  2.67238190e+00
  2.13487038e-03 -1.56060831e+00]
控制循环错误: 
控制循环错误: