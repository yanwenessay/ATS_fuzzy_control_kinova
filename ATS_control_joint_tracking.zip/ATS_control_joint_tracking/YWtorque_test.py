#!/usr/bin/env python3

###
# Kinova Gen3机械臂变阻抗控制器 - 基于Lyapunov稳定性理论
# 
# 主要功能：
# 1. 基于Lyapunov理论的稳定性验证
# 2. 时变刚度K(t)和阻尼D(t)控制
# 3. 状态无关的稳定性条件验证
# 4. 实时稳定性监控
# 5. 自适应阻抗参数调整
# 6. 安全模式保护
# 7. 交互式用户界面
###

import sys
import os
import numpy as np
import time
import threading
import argparse
from collections import deque
import math
from scipy import signal
from scipy.linalg import eigvals, norm

from kortex_api.autogen.client_stubs.ActuatorConfigClientRpc import ActuatorConfigClient
from kortex_api.autogen.client_stubs.BaseClientRpc import BaseClient
from kortex_api.autogen.client_stubs.BaseCyclicClientRpc import BaseCyclicClient
from kortex_api.autogen.client_stubs.DeviceConfigClientRpc import DeviceConfigClient
from kortex_api.autogen.client_stubs.DeviceManagerClientRpc import DeviceManagerClient
from kortex_api.autogen.messages import Session_pb2, ActuatorConfig_pb2, Base_pb2, BaseCyclic_pb2, Common_pb2
from kortex_api.RouterClient import RouterClientSendOptions


class LyapunovStabilityAnalyzer:
    """
    基于Lyapunov理论的变阻抗控制稳定性分析器
    实现研究论文中的理论框架
    """
    
    def __init__(self, dof=6):
        self.dof = dof  # 笛卡尔空间自由度数量
        
        # 虚拟惯性矩阵H（常数，正定）- 针对Kinova Gen3优化
        self.H = np.eye(dof) * 0.5  # 适中的惯性值以提高稳定性
        
        # Lyapunov参数α用于稳定性条件 - 针对7轴机械臂优化
        self.alpha = 0.3  # 保守的α值确保稳定性裕度
        
        # 用于存储时变参数的历史记录
        self.K_history = deque(maxlen=100)  # 刚度历史记录
        self.D_history = deque(maxlen=100)  # 阻尼历史记录
        self.time_history = deque(maxlen=100)  # 时间历史记录
        
        # 稳定性标志位
        self.is_stable_V1 = True  # 能量型Lyapunov稳定性
        self.is_stable_V2 = True  # 广义Lyapunov稳定性
        self.stability_margin = 0.0  # 稳定性裕度
        
        print(f"Lyapunov稳定性分析器已初始化，参数α={self.alpha}")
    
    def offline_stability_verification(self, K_profile, D_profile, K_dot_profile, D_dot_profile, 
                                     time_points, max_iterations=50):
        """
        离线验证完整K(t)和D(t)配置文件的稳定性
        针对Kinova Gen3 7轴机械臂优化的稳定性验证算法
        """
        print("开始离线稳定性验证阻抗配置文件...")
        print(f"针对Kinova Gen3 7轴机械臂优化，Lyapunov参数α={self.alpha}")
        
        # 复制原始数据进行修改，避免影响输入参数
        K_mod = [K.copy() for K in K_profile]
        D_mod = [D.copy() for D in D_profile] 
        K_dot_mod = [Kd.copy() for Kd in K_dot_profile]
        D_dot_mod = [Dd.copy() for Dd in D_dot_profile]
        
        iteration = 0  # 迭代计数器
        all_stable = False  # 全局稳定性标志
        
        # 为机械臂应用设置合理的稳定性容差
        stability_tolerance = 1e-3  # 稳定性判断容差
        
        while not all_stable and iteration < max_iterations:
            iteration += 1
            unstable_points = []  # 存储不稳定时间点的列表
            
            # 逐一检查每个时间点的稳定性条件
            for i, t in enumerate(time_points):
                # 检查稳定性条件1：α*H - D(t) ≤ 0
                stable_1, margin_1 = self.check_stability_condition_1(D_mod[i])
                
                # 检查稳定性条件2：K̇(t) + α*Ḋ(t) - 2α*K(t) ≤ 0
                stable_2, margin_2 = self.check_stability_condition_2(
                    K_mod[i], K_dot_mod[i], D_mod[i], D_dot_mod[i])
                
                # 如果任一条件违规，记录该时间点
                if margin_1 > stability_tolerance or margin_2 > stability_tolerance:
                    unstable_points.append((i, margin_1, margin_2))
            
            # 如果所有时间点都稳定，退出循环
            if not unstable_points:
                all_stable = True
                print(f"所有配置文件在{iteration}次迭代后达到稳定")
                break
            
            # 对不稳定点进行参数调整（针对7轴机械臂优化）
            for i, margin_1, margin_2 in unstable_points:
                # 条件1违规：增加阻尼矩阵的值
                if margin_1 > stability_tolerance:
                    adjustment = max(margin_1 * 2.0, 0.1)  # 计算调整量
                    D_mod[i] += adjustment * np.eye(self.dof)  # 增加阻尼
                    
                # 条件2违规：减少参数变化率
                if margin_2 > stability_tolerance:
                    # 减少刚度和阻尼的时间变化率
                    K_dot_mod[i] *= 0.5  # 减半刚度变化率
                    D_dot_mod[i] *= 0.5  # 减半阻尼变化率
                    
                    # 确保刚度不会降到过低影响性能
                    min_K_diag = 5.0  # 最小刚度对角值
                    for j in range(self.dof):
                        if K_mod[i][j, j] < min_K_diag:
                            K_mod[i][j, j] = min_K_diag
                
                # 强制确保矩阵的正定性
                K_mod[i] = self._ensure_positive_definite(K_mod[i], min_eigenvalue=1.0)
                D_mod[i] = self._ensure_positive_definite(D_mod[i], min_eigenvalue=2.0)
            
            # 每10次迭代显示进度
            if iteration % 10 == 0:
                print(f"迭代{iteration}: 剩余{len(unstable_points)}个不稳定时间点")
        
        # 如果无法在规定迭代内稳定，采用保守的安全配置
        if not all_stable:
            print(f"警告：在{max_iterations}次迭代内无法稳定所有配置文件")
            print("正在应用Kinova Gen3保守安全配置文件...")
            
            # 使用经过验证的保守但稳定的参数配置
            for i in range(len(K_mod)):
                # 保守的刚度配置（针对7轴机械臂特点）
                K_safe = np.diag([10.0, 10.0, 10.0, 1.0, 1.0, 1.0])  # 位置和姿态分别设置
                D_safe = np.diag([8.0, 8.0, 8.0, 0.8, 0.8, 0.8])  # 对应的阻尼配置
                
                K_mod[i] = K_safe.copy()
                D_mod[i] = D_safe.copy()
                K_dot_mod[i] = np.zeros((self.dof, self.dof))  # 零时间导数
                D_dot_mod[i] = np.zeros((self.dof, self.dof))
            
            # 验证安全配置的稳定性
            all_stable = True
            for i in range(len(K_mod)):
                stable_1, _ = self.check_stability_condition_1(D_mod[i])
                stable_2, _ = self.check_stability_condition_2(
                    K_mod[i], K_dot_mod[i], D_mod[i], D_dot_mod[i])
                if not (stable_1 and stable_2):
                    all_stable = False
                    break
            
            if all_stable:
                print("✓ 保守安全配置文件验证稳定")
                iteration = max_iterations  # 标记使用了安全配置
            else:
                print("✗ 错误：连保守安全配置都不满足稳定性条件！")
        
        # 组装验证结果
        verified_profiles = {
            'K_profile': K_mod,
            'D_profile': D_mod,
            'K_dot_profile': K_dot_mod,
            'D_dot_profile': D_dot_mod,
            'time_points': time_points,
            'iterations_required': iteration
        }
        
        # 显示最终验证结果
        if all_stable:
            print("✓ 离线验证成功 - 所有配置文件满足稳定性条件")
            if iteration >= max_iterations:
                print("  注意：使用了Kinova Gen3保守安全配置文件")
        else:
            print(f"✗ 失败：无法在{max_iterations}次迭代内稳定配置文件")
        
        return verified_profiles, all_stable
    
    def generate_test_profiles(self, duration=10.0, dt=0.1):
        """
        为Kinova Gen3 7轴机械臂生成测试用的K(t)和D(t)时变配置文件
        针对实际机械臂特性和应用场景优化的阻抗参数设计
        """
        time_points = np.arange(0, duration, dt)  # 生成时间序列
        K_profile = []  # 刚度配置文件列表
        D_profile = []  # 阻尼配置文件列表
        K_dot_profile = []  # 刚度导数配置文件列表
        D_dot_profile = []  # 阻尼导数配置文件列表
        
        print(f"为Kinova Gen3生成{len(time_points)}个配置文件时间点")
        
        for t in time_points:
            # 设计针对7轴机械臂的时变阻抗策略
            if t < 2.0 or t > 8.0:  # 自主操作阶段
                K_base = 30.0  
            else:  # 人机交互阶段
                K_base = 15.0  
            
            # 为7轴机械臂设计的分层刚度配置
            K_t = np.diag([
                K_base,      # X方向位置刚度
                K_base,      # Y方向位置刚度  
                K_base,      # Z方向位置刚度
                K_base*0.2,  # 绕X轴姿态刚度
                K_base*0.2,  # 绕Y轴姿态刚度
                K_base*0.2   # 绕Z轴姿态刚度
            ])
            
            # D(t): 在模式切换期间增加阻尼
            if 1.5 < t < 2.5 or 7.5 < t < 8.5:  # 模式切换过渡期间
                D_base = 12.0  
            else:
                D_base = 8.0   
            
            # 为7轴机械臂设计的分层阻尼配置
            D_t = np.diag([
                D_base,      # X方向位置阻尼
                D_base,      # Y方向位置阻尼
                D_base,      # Z方向位置阻尼  
                D_base*0.15, # 绕X轴姿态阻尼
                D_base*0.15, # 绕Y轴姿态阻尼
                D_base*0.15  # 绕Z轴姿态阻尼
            ])
            
            # 计算平滑的时间导数
            K_dot_t = np.zeros((self.dof, self.dof))  
            D_dot_t = np.zeros((self.dof, self.dof))  
            
            if len(K_profile) > 0:
                # 使用数值微分计算时间导数
                K_dot_t = (K_t - K_profile[-1]) / dt
                D_dot_t = (D_t - D_profile[-1]) / dt
                
                # 限制导数幅度以确保Lyapunov稳定性
                max_K_dot = 5.0  
                max_D_dot = 3.0  
                
                # 对导数矩阵进行幅度限制
                K_dot_t = np.clip(K_dot_t, -max_K_dot, max_K_dot)
                D_dot_t = np.clip(D_dot_t, -max_D_dot, max_D_dot)
            
            # 将当前时间点的参数添加到配置文件中
            K_profile.append(K_t)
            D_profile.append(D_t)
            K_dot_profile.append(K_dot_t)
            D_dot_profile.append(D_dot_t)
        
        print("Kinova Gen3时变阻抗配置文件生成完成")
        return K_profile, D_profile, K_dot_profile, D_dot_profile, time_points
    
    def compute_lyapunov_V1(self, q_tilde, q_tilde_dot, K_t):
        """计算基于能量的Lyapunov函数V1"""
        try:
            K_t_pd = self._ensure_positive_definite(K_t)
            kinetic_energy = 0.5 * q_tilde_dot.T @ self.H @ q_tilde_dot
            potential_energy = 0.5 * q_tilde.T @ K_t_pd @ q_tilde
            V1 = kinetic_energy + potential_energy  
            return float(V1)
        except Exception as e:
            print(f"计算V1时出错: {e}")
            return 0.0
    
    def compute_lyapunov_V2(self, q_tilde, q_tilde_dot, K_t, D_t):
        """计算广义Lyapunov函数V2"""
        try:
            beta_t = K_t + self.alpha * D_t - (self.alpha**2) * self.H
            beta_t_pd = self._ensure_positive_definite(beta_t)
            composite_velocity = q_tilde_dot + self.alpha * q_tilde
            first_term = composite_velocity.T @ self.H @ composite_velocity
            second_term = q_tilde.T @ beta_t_pd @ q_tilde
            V2 = first_term + second_term  
            return float(V2)
        except Exception as e:
            print(f"计算V2时出错: {e}")
            return 0.0
    
    def check_stability_condition_1(self, D_t):
        """检查稳定性条件1: α*H - D(t) 必须为负半定矩阵"""
        try:
            matrix = self.alpha * self.H - D_t
            eigenvalues = np.real(eigvals(matrix))
            max_eigenvalue = np.max(eigenvalues)
            is_stable = max_eigenvalue <= 1e-6  
            return is_stable, max_eigenvalue
        except Exception as e:
            print(f"稳定性条件1检查出错: {e}")
            return False, float('inf')
    
    def check_stability_condition_2(self, K_t, K_dot, D_t, D_dot):
        """检查稳定性条件2"""
        try:
            matrix = K_dot + self.alpha * D_dot - 2 * self.alpha * K_t
            eigenvalues = np.real(eigvals(matrix))
            max_eigenvalue = np.max(eigenvalues)
            is_stable = max_eigenvalue <= 1e-6  
            return is_stable, max_eigenvalue
        except Exception as e:
            print(f"稳定性条件2检查出错: {e}")
            return False, float('inf')
    
    def verify_stability(self, K_t, D_t, K_dot=None, D_dot=None):
        """综合稳定性验证"""
        result = {
            'condition_1_stable': False,     
            'condition_2_stable': False,     
            'overall_stable': False,         
            'stability_margin_1': float('inf'),  
            'stability_margin_2': float('inf'),  
            'recommendations': []            
        }
        
        # 检查条件1
        stable_1, margin_1 = self.check_stability_condition_1(D_t)
        result['condition_1_stable'] = stable_1
        result['stability_margin_1'] = margin_1
        
        if not stable_1:
            result['recommendations'].append(f"增加阻尼D(t)至少{margin_1:.4f}")
        
        # 如果提供了导数，检查条件2
        if K_dot is not None and D_dot is not None:
            stable_2, margin_2 = self.check_stability_condition_2(K_t, K_dot, D_t, D_dot)
            result['condition_2_stable'] = stable_2
            result['stability_margin_2'] = margin_2
            
            if not stable_2:
                result['recommendations'].append(f"调整参数时间导数，裕度不足: {margin_2:.4f}")
        else:
            result['condition_2_stable'] = True
        
        # 确定整体稳定性
        result['overall_stable'] = stable_1 and result['condition_2_stable']
        
        # 更新内部稳定性标志
        self.is_stable_V1 = stable_1
        self.is_stable_V2 = result['overall_stable']
        self.stability_margin = min(abs(margin_1), abs(result['stability_margin_2']))
        
        return result
    
    def _ensure_positive_definite(self, matrix, min_eigenvalue=1e-6):
        """确保矩阵为正定"""
        try:
            eigenvalues = np.real(eigvals(matrix))
            min_eig = np.min(eigenvalues)
            
            if min_eig > min_eigenvalue:
                return matrix  
            else:
                regularization = (min_eigenvalue - min_eig + 1e-8) * np.eye(matrix.shape[0])
                return matrix + regularization
        except:
            return np.eye(matrix.shape[0]) * min_eigenvalue
    
    def estimate_time_derivatives(self, current_params, param_history, time_history):
        """使用数值微分估算时间导数"""
        if len(param_history) < 3 or len(time_history) < 3:
            return np.zeros_like(current_params)
        
        try:
            dt1 = time_history[-1] - time_history[-2]  
            dt2 = time_history[-2] - time_history[-3]  
            
            if dt1 <= 0 or dt2 <= 0:
                return np.zeros_like(current_params)
            
            param_dot = (param_history[-1] - param_history[-2]) / dt1
            return param_dot
        except:
            return np.zeros_like(current_params)


class VariableImpedanceController:
    """
    基于Lyapunov稳定性验证的变阻抗控制器
    实现时变刚度和阻尼控制，具有稳定性保证
    """
    
    def __init__(self, router, router_real_time):
        # 网络连接相关
        self.router = router  
        self.router_real_time = router_real_time  
        
        # 创建Kortex API服务客户端
        device_manager = DeviceManagerClient(router)
        self.actuator_config = ActuatorConfigClient(router)  
        self.base = BaseClient(router)  
        self.base_cyclic = BaseCyclicClient(router_real_time)  
        
        # 初始化命令和反馈数据结构
        self.base_command = BaseCyclic_pb2.Command()  
        self.base_feedback = BaseCyclic_pb2.Feedback()  
        
        # 获取机器人配置信息
        self.actuator_count = self.base.GetActuatorCount().count  
        device_handles = device_manager.ReadAllDevices()  
        
        # 为每个执行器初始化命令和反馈结构
        for handle in device_handles.device_handle:
            if handle.device_type == Common_pb2.BIG_ACTUATOR or handle.device_type == Common_pb2.SMALL_ACTUATOR:
                self.base_command.actuators.add()  
                self.base_feedback.actuators.add()  
        
        # 通信选项配置
        self.sendOption = RouterClientSendOptions()  
        self.sendOption.andForget = False  
        self.sendOption.delay_ms = 0  
        self.sendOption.timeout_ms = 10  
        
        # ====== 变阻抗控制参数设置 ======
        
        # 笛卡尔空间自由度
        self.cartesian_dof = 6
        
        # 初始化Lyapunov稳定性分析器
        self.stability_analyzer = LyapunovStabilityAnalyzer(self.cartesian_dof)
        
        # 时变阻抗参数
        self.K_t = np.diag([25.0, 25.0, 25.0, 2.5, 2.5, 2.5])  
        self.D_t = np.diag([10.0, 10.0, 10.0, 1.0, 1.0, 1.0])  
        self.K_dot = np.zeros((self.cartesian_dof, self.cartesian_dof))  
        self.D_dot = np.zeros((self.cartesian_dof, self.cartesian_dof))  
        
        # 目标阻抗参数
        self.K_target = self.K_t.copy()  
        self.D_target = self.D_t.copy()  
        
        # 阻抗参数边界约束
        self.K_min = np.diag([5.0, 5.0, 5.0, 0.5, 0.5, 0.5])      
        self.K_max = np.diag([100.0, 100.0, 100.0, 10.0, 10.0, 10.0])  
        self.D_min = np.diag([2.0, 2.0, 2.0, 0.2, 0.2, 0.2])      
        self.D_max = np.diag([30.0, 30.0, 30.0, 3.0, 3.0, 3.0])   
        
        # 控制系统参数
        self.control_rate = 0.005  
        self.stability_check_rate = 0.05  
        
        # 笛卡尔空间状态变量
        self.X = np.zeros(self.cartesian_dof)      
        self.X_dot = np.zeros(self.cartesian_dof)  
        self.X_ddot = np.zeros(self.cartesian_dof) 
        
        self.X_d = np.zeros(self.cartesian_dof)      
        self.X_d_dot = np.zeros(self.cartesian_dof)  
        self.X_d_ddot = np.zeros(self.cartesian_dof) 
        
        self.X_0 = np.zeros(self.cartesian_dof)    
        
        # 误差变量
        self.q_tilde = np.zeros(self.cartesian_dof)      
        self.q_tilde_dot = np.zeros(self.cartesian_dof)  
        
        # 外部作用力/力矩
        self.F_ext = np.zeros(self.cartesian_dof)  
        self.tau_ext = np.zeros(self.actuator_count)  
        
        # 关节空间变量
        self.q = np.zeros(self.actuator_count)     
        self.q_dot = np.zeros(self.actuator_count) 
        self.q_ddot = np.zeros(self.actuator_count)
        
        # 雅可比矩阵
        self.J = np.zeros((self.cartesian_dof, self.actuator_count))  
        
        # 初始化雅可比矩阵
        for i in range(self.cartesian_dof):  
            if i < self.actuator_count:
                self.J[i, i] = 0.3  
            if self.actuator_count > self.cartesian_dof:  
                self.J[i % self.cartesian_dof, -1] = 0.1  
        
        print(f"雅可比矩阵J初始化为{self.J.shape}维度（笛卡尔{self.cartesian_dof}×关节{self.actuator_count}）")
        
        # 动力学模型参数
        self.M_q = np.eye(self.actuator_count) * 2.0  
        self.C_q = np.eye(self.actuator_count) * 0.3  
        self.G_q = np.zeros(self.actuator_count)      
        
        # 控制系统标志位
        self.control_running = False  
        self.kill_thread = False     
        self.control_thread = None   
        self.stability_thread = None 
        self.is_initialized = False  # 新增：系统是否已初始化标志
        
        # 力传感标定相关
        self.torque_bias = np.zeros(self.actuator_count)  
        self.bias_calibrated = False  
        self.force_threshold = 2.0   
        
        # 数据历史记录
        self.position_history = deque(maxlen=50)  
        self.velocity_history = deque(maxlen=50)  
        self.K_history = deque(maxlen=100)  
        self.D_history = deque(maxlen=100)  
        self.time_history = deque(maxlen=100)  
        
        # 初始化历史记录
        for _ in range(10):
            self.position_history.append(np.zeros(self.cartesian_dof))
            self.velocity_history.append(np.zeros(self.cartesian_dof))
            self.K_history.append(self.K_t.copy())
            self.D_history.append(self.D_t.copy())
            self.time_history.append(time.time())
        
        # 滤波参数
        self.alpha_filter = 0.1  
        self.force_filter_history = deque(maxlen=10)  
        
        for _ in range(5):
            self.force_filter_history.append(np.zeros(self.cartesian_dof))
        
        # 稳定性监控相关
        self.last_stability_check = time.time()  
        self.stability_violations = 0  
        self.max_violations = 5       
        
        # 预验证的阻抗配置文件
        self.verified_K_profile = None  
        self.verified_D_profile = None  
        self.profile_time_points = None 
        self.profile_start_time = None  
        self.profiles_verified = False  
        
        # 任务执行参数
        self.task_phase = "静止"  
        self.interaction_detected = False  
    
    def normalize_joint_angle(self, angle_rad):
        """将关节角度规范化到[-π, π]范围内"""
        while angle_rad > math.pi:
            angle_rad -= 2 * math.pi
        while angle_rad < -math.pi:
            angle_rad += 2 * math.pi
        return angle_rad
    
    def get_current_joint_angles_safe(self):
        """安全地获取当前关节角度"""
        try:
            feedback = self.base_cyclic.RefreshFeedback()
            current_angles = np.zeros(self.actuator_count)
            
            for i in range(self.actuator_count):
                raw_angle = feedback.actuators[i].position  
                normalized_angle = self.normalize_joint_angle(raw_angle)  
                current_angles[i] = normalized_angle
            
            return current_angles
        except Exception as e:
            print(f"获取关节角度时出错: {e}")
            return np.zeros(self.actuator_count)  
    
    def offline_profile_verification_and_setup(self, task_duration=10.0):
        """完整的离线配置文件验证和设置流程"""
        print("\n=== 开始离线配置文件验证 ===")
        
        # 生成配置文件
        print("正在生成任务特定的K(t)和D(t)配置文件...")
        K_profile, D_profile, K_dot_profile, D_dot_profile, time_points = \
            self.stability_analyzer.generate_test_profiles(duration=task_duration, dt=0.1)
        
        print(f"已生成{len(K_profile)}个配置文件点，时长{task_duration:.1f}秒")
        
        # 离线稳定性验证
        verified_profiles, is_stable = self.stability_analyzer.offline_stability_verification(
            K_profile, D_profile, K_dot_profile, D_dot_profile, time_points)
        
        if is_stable:
            # 存储验证后的配置文件
            self.verified_K_profile = verified_profiles['K_profile']
            self.verified_D_profile = verified_profiles['D_profile']
            self.profile_time_points = verified_profiles['time_points']
            self.profiles_verified = True
            
            print(f"✓ 配置文件验证成功，可以执行")
            print(f"  所需迭代次数: {verified_profiles['iterations_required']}")
            print(f"  配置文件时长: {time_points[-1]:.1f} 秒")
            
            return True
        else:
            print("✗ 配置文件验证失败 - 无法保证稳定性")
            return False
    
    def execute_verified_profiles(self, current_time):
        """执行预验证的阻抗配置文件"""
        if not self.profiles_verified:
            return
        
        # 计算配置文件执行的经过时间
        if self.profile_start_time is None:
            self.profile_start_time = current_time
            print("开始执行验证后的阻抗配置文件")
        
        elapsed_time = current_time - self.profile_start_time
        
        # 确定当前配置文件索引
        if elapsed_time >= self.profile_time_points[-1]:
            profile_idx = len(self.verified_K_profile) - 1
        else:
            profile_idx = 0
            for i, t in enumerate(self.profile_time_points):
                if elapsed_time <= t:
                    profile_idx = i
                    break
        
        # 更新阻抗参数
        self.K_t = self.verified_K_profile[profile_idx].copy()
        self.D_t = self.verified_D_profile[profile_idx].copy()
        
        # 更新导数
        if profile_idx > 0:
            dt_profile = self.profile_time_points[profile_idx] - self.profile_time_points[profile_idx-1]
            self.K_dot = (self.verified_K_profile[profile_idx] - 
                         self.verified_K_profile[profile_idx-1]) / dt_profile
            self.D_dot = (self.verified_D_profile[profile_idx] - 
                         self.verified_D_profile[profile_idx-1]) / dt_profile
    
    def impedance_task_adaptation(self, current_time):
        """根据任务需求自适应调整阻抗参数"""
        
        if self.interaction_detected:
            # 人机交互期间: 降低刚度，增加阻尼
            self.K_target = np.diag([50.0, 50.0, 50.0, 5.0, 5.0, 5.0])
            self.D_target = np.diag([40.0, 40.0, 40.0, 4.0, 4.0, 4.0])
            self.task_phase = "交互"
        else:
            # 自主操作期间: 增加刚度，适中阻尼
            self.K_target = np.diag([200.0, 200.0, 200.0, 20.0, 20.0, 20.0])
            self.D_target = np.diag([30.0, 30.0, 30.0, 3.0, 3.0, 3.0])
            self.task_phase = "自主"
        
        # 向目标阻抗平滑过渡
        adaptation_rate = 2.0  
        dt = self.control_rate  
        
        K_error = self.K_target - self.K_t
        self.K_dot = adaptation_rate * K_error
        
        D_error = self.D_target - self.D_t
        self.D_dot = adaptation_rate * D_error
        
        # 限制导数幅度
        max_K_dot = 50.0  
        max_D_dot = 20.0  
        
        self.K_dot = np.clip(self.K_dot, -max_K_dot, max_K_dot)
        self.D_dot = np.clip(self.D_dot, -max_D_dot, max_D_dot)
        
        # 积分更新阻抗参数
        self.K_t += self.K_dot * dt
        self.D_t += self.D_dot * dt
        
        # 应用边界约束
        self.K_t = np.maximum(self.K_min, np.minimum(self.K_max, self.K_t))
        self.D_t = np.maximum(self.D_min, np.minimum(self.D_max, self.D_t))
        
        # 更新历史记录
        self.K_history.append(self.K_t.copy())
        self.D_history.append(self.D_t.copy())
        self.time_history.append(current_time)
    
    def verify_stability_conditions(self):
        """实时稳定性验证"""
        current_time = time.time()
        
        if current_time - self.last_stability_check < self.stability_check_rate:
            return True
        
        self.last_stability_check = current_time
        
        # 估算时间导数
        if len(self.K_history) >= 3:
            K_dot_est = self.stability_analyzer.estimate_time_derivatives(
                self.K_t, list(self.K_history), list(self.time_history))
            D_dot_est = self.stability_analyzer.estimate_time_derivatives(
                self.D_t, list(self.D_history), list(self.time_history))
        else:
            K_dot_est = self.K_dot
            D_dot_est = self.D_dot
        
        # 执行稳定性验证
        stability_result = self.stability_analyzer.verify_stability(
            self.K_t, self.D_t, K_dot_est, D_dot_est)
        
        if not stability_result['overall_stable']:
            self.stability_violations += 1
            print(f"检测到稳定性违规！计数: {self.stability_violations}")
            
            # 应用纠正措施
            if stability_result['stability_margin_1'] > 0:
                damping_increase = stability_result['stability_margin_1'] + 0.1
                self.D_t += np.eye(self.cartesian_dof) * damping_increase
                print(f"已增加阻尼 {damping_increase:.3f}")
            
            if self.stability_violations > self.max_violations:
                print("稳定性违规次数过多 - 切换到安全模式")
                self.activate_safe_mode()
                return False
        else:
            self.stability_violations = max(0, self.stability_violations - 1)
        
        return stability_result['overall_stable']
    
    def activate_safe_mode(self):
        """激活安全模式"""
        print("正在激活安全模式 - 使用保证稳定的参数")
        
        # 设置保守的阻抗参数
        self.K_t = np.diag([30.0, 30.0, 30.0, 3.0, 3.0, 3.0])
        self.D_t = np.diag([50.0, 50.0, 50.0, 5.0, 5.0, 5.0])
        
        # 零导数
        self.K_dot = np.zeros((self.cartesian_dof, self.cartesian_dof))
        self.D_dot = np.zeros((self.cartesian_dof, self.cartesian_dof))
        
        # 验证安全参数
        stability_result = self.stability_analyzer.verify_stability(
            self.K_t, self.D_t, self.K_dot, self.D_dot)
        
        if stability_result['overall_stable']:
            print("安全模式参数验证稳定")
            self.stability_violations = 0
        else:
            print("错误: 连安全模式参数都不稳定！")
    
    def variable_impedance_control_law(self, dt):
        """变阻抗控制律 - 基于Lyapunov稳定性理论"""
        
        # 更新误差变量
        self.q_tilde = self.X_d - self.X          
        self.q_tilde_dot = self.X_d_dot - self.X_dot  
        
        # 检测人机交互
        force_magnitude = np.linalg.norm(self.F_ext[:3])      
        torque_magnitude = np.linalg.norm(self.F_ext[3:])     
        
        self.interaction_detected = (force_magnitude > self.force_threshold or 
                                   torque_magnitude > self.force_threshold * 0.5)
        
        # 执行阻抗配置文件
        if self.profiles_verified:
            self.execute_verified_profiles(time.time())
        else:
            self.impedance_task_adaptation(time.time())
        
        # 实时稳定性监控
        if not self.verify_stability_conditions():
            print("执行过程中检测到实时稳定性违规")
        
        # 基于阻抗模型计算期望加速度
        try:
            if self.q_tilde.shape[0] != self.cartesian_dof or self.q_tilde_dot.shape[0] != self.cartesian_dof:
                print(f"维度错误：q_tilde={self.q_tilde.shape}, q_tilde_dot={self.q_tilde_dot.shape}")
                return
            
            H_inv = np.linalg.pinv(self.stability_analyzer.H)  
            
            # 阻抗控制律
            impedance_force = (self.K_t @ self.q_tilde +     
                             self.D_t @ self.q_tilde_dot -   
                             self.F_ext * 0.8)               
            
            if impedance_force.shape[0] != self.cartesian_dof:
                print(f"阻抗力维度错误：{impedance_force.shape}")
                return
            
            self.X_d_ddot = H_inv @ impedance_force  
            
            # 安全措施：限制加速度
            max_acc = 0.5  
            self.X_d_ddot = np.clip(self.X_d_ddot, -max_acc, max_acc)
            
            # 积分得到期望速度
            self.X_d_dot += self.X_d_ddot * dt
            max_vel = 0.05  
            self.X_d_dot = np.clip(self.X_d_dot, -max_vel, max_vel)
            
            # 更新期望位置
            self.X_d += self.X_d_dot * dt
            
            # 限制位置变化
            max_pos_change = 0.0005  
            pos_change = self.X_d_dot * dt
            if np.linalg.norm(pos_change) > max_pos_change:
                scale_factor = max_pos_change / np.linalg.norm(pos_change)
                self.X_d_dot *= scale_factor
            
        except Exception as e:
            print(f"阻抗控制律计算错误: {e}")
            # 安全回退
            self.X_d_ddot = np.zeros(self.cartesian_dof)  
            self.X_d_dot *= 0.1   
    
    def compute_lyapunov_functions(self):
        """计算Lyapunov函数"""
        try:
            V1 = self.stability_analyzer.compute_lyapunov_V1(
                self.q_tilde, self.q_tilde_dot, self.K_t)
            
            V2 = self.stability_analyzer.compute_lyapunov_V2(
                self.q_tilde, self.q_tilde_dot, self.K_t, self.D_t)
            
            return V1, V2
        except Exception as e:
            print(f"计算Lyapunov函数时出错: {e}")
            return 0.0, 0.0
    
    def get_cartesian_pose(self):
        """获取当前笛卡尔位姿"""
        try:
            cartesian_pose = self.base.GetMeasuredCartesianPose()
            
            current_X = np.array([
                cartesian_pose.x,        
                cartesian_pose.y,        
                cartesian_pose.z,        
                cartesian_pose.theta_x,  
                cartesian_pose.theta_y,  
                cartesian_pose.theta_z   
            ])
            
            self.position_history.append(current_X.copy())
            
            # 应用移动平均滤波
            self.X = np.mean(np.array(list(self.position_history)), axis=0)
            
        except Exception as e:
            print(f"获取笛卡尔位姿时出错: {e}")
    
    def estimate_external_wrench(self):
        """估算外部交互力和力矩"""
        tau_measured = np.zeros(self.actuator_count)
        for i in range(self.actuator_count):
            measured_torque = self.base_feedback.actuators[i].torque
            if self.bias_calibrated:  
                measured_torque -= self.torque_bias[i]  
            tau_measured[i] = measured_torque
        
        # 估算期望力矩
        tau_expected = (self.M_q @ self.q_ddot +   
                       self.C_q @ self.q_dot +    
                       self.G_q)                  
        
        # 计算外部关节力矩
        self.tau_ext = tau_measured - tau_expected
        self.tau_ext = np.clip(self.tau_ext, -20.0, 20.0)  
        
        # 映射到笛卡尔空间
        try:
            F_raw = self.J @ self.tau_ext  
            F_raw = np.clip(F_raw, -50.0, 50.0)  
            
            # 应用滤波
            self.force_filter_history.append(F_raw.copy())
            self.F_ext = np.mean(np.array(list(self.force_filter_history)), axis=0)
            
        except Exception as e:
            print(f"外力估算错误: {e}")
            self.F_ext = np.zeros(self.cartesian_dof)
    
    def estimate_cartesian_velocity(self, dt):
        """估算笛卡尔空间速度"""
        if len(self.position_history) < 2:
            self.X_dot = np.zeros(self.cartesian_dof)
            return
        
        # 使用后向差分法
        self.X_dot = (self.position_history[-1] - self.position_history[-2]) / dt
        
        # 对速度进行滤波
        self.velocity_history.append(self.X_dot.copy())
        if len(self.velocity_history) >= 3:
            self.X_dot = np.mean(np.array(list(self.velocity_history)[-3:]), axis=0)
        
        # 限制速度
        max_vel = 0.5
        self.X_dot = np.clip(self.X_dot, -max_vel, max_vel)
    
    def joint_space_control_law(self, dt):
        """关节空间控制律"""
        try:
            J_pinv = np.linalg.pinv(self.J)  
            
            # 映射到关节空间
            q_d_ddot = J_pinv @ self.X_d_ddot  
            q_d_dot = J_pinv @ self.X_d_dot    
            
            # 安全限制
            max_joint_acc = 0.05   
            max_joint_vel = 0.02   
            
            q_d_ddot = np.clip(q_d_ddot, -max_joint_acc, max_joint_acc)
            q_d_dot = np.clip(q_d_dot, -max_joint_vel, max_joint_vel)
            
            # 关节空间PD控制
            Kp_joint = np.diag([10.0] * self.actuator_count)  
            Kd_joint = np.diag([2.0] * self.actuator_count)   
            
            # 计算控制力矩
            tau_control = (Kp_joint @ (q_d_ddot * dt - (self.q_dot - q_d_dot)) +
                          Kd_joint @ (q_d_dot - self.q_dot))
            
            # 动力学前馈补偿
            tau_dynamics = (self.M_q @ q_d_ddot +   
                           self.C_q @ self.q_dot +  
                           self.G_q)                
            
            tau_total = tau_control + tau_dynamics  
            
            # 力矩限制
            max_torque = 2.0  
            tau_total = np.clip(tau_total, -max_torque, max_torque)
            
            # 转换为位置指令
            for i in range(self.actuator_count):
                desired_velocity = tau_total[i] * 0.00005  
                desired_velocity = np.clip(desired_velocity, -0.01, 0.01)  
                
                new_position = self.q[i] + desired_velocity * dt
                
                # 安全检查
                max_single_step = 0.0005  
                position_change = abs(new_position - self.q[i])
                
                if position_change > max_single_step:
                    scale_factor = max_single_step / position_change
                    new_position = self.q[i] + (new_position - self.q[i]) * scale_factor
                
                # 关节范围限制
                new_position = np.clip(new_position, -math.pi, math.pi)
                
                # 最终安全验证
                if abs(new_position - self.q[i]) > 0.002:
                    new_position = self.q[i]  
                
                # 设置关节位置命令
                self.base_command.actuators[i].position = new_position
                
        except Exception as e:
            print(f"关节空间控制计算错误: {e}")
            # 紧急安全措施
            for i in range(self.actuator_count):
                self.base_command.actuators[i].position = self.q[i]
    
    def move_to_initial_position(self):
        """移动到安全的初始位置"""
        # 设置单层伺服模式
        base_servo_mode = Base_pb2.ServoingModeInformation()
        base_servo_mode.servoing_mode = Base_pb2.SINGLE_LEVEL_SERVOING
        self.base.SetServoingMode(base_servo_mode)
        
        print("正在将机械臂移动到初始位置...")
        
        # 获取当前关节角度
        try:
            current_angles_rad = self.get_current_joint_angles_safe()  
            current_angles_deg = [math.degrees(angle) for angle in current_angles_rad]
            print(f"当前关节角度: {[f'{a:.1f}' for a in current_angles_deg]} 度")
        except:
            print("无法获取当前关节角度")
            current_angles_deg = [0.0] * self.actuator_count
        
        # 设置目标角度
        target_angles_deg = [0.0, 15.0, 0.0, -90.0, 0.0, -75.0, 90.0]  
        
        # 安全检查
        max_movement = 0
        for i, (current_deg, target_deg) in enumerate(zip(current_angles_deg, target_angles_deg)):
            movement = abs(target_deg - current_deg)
            max_movement = max(max_movement, movement)
        
        print(f"预计最大关节运动幅度: {max_movement:.1f} 度")
        
        if max_movement > 45.0:  
            print("⚠️ 警告：检测到较大幅度关节运动")
            print("为安全起见，将使用当前位置作为初始位置")
            self.get_cartesian_pose()
            self.X_0 = self.X.copy()
            self.X_d = self.X.copy()
            return True
        
        # 执行移动
        print("运动幅度合理，执行移动到初始位置")
        
        constrained_joint_angles = Base_pb2.ConstrainedJointAngles()
        
        for joint_id in range(self.actuator_count):
            joint_angle = constrained_joint_angles.joint_angles.joint_angles.add()
            joint_angle.joint_identifier = joint_id
            joint_angle.value = target_angles_deg[joint_id]  
        
        # 设置动作监听
        e = threading.Event()
        notification_handle = self.base.OnNotificationActionTopic(
            self.check_for_end_or_abort(e),
            Base_pb2.NotificationOptions()
        )
        
        print("开始执行关节轨迹运动...")
        self.base.PlayJointTrajectory(constrained_joint_angles)
        
        print("等待移动完成...")
        finished = e.wait(20)  
        self.base.Unsubscribe(notification_handle)
        
        if finished:
            print("✓ 成功移动到初始位置")
            self.get_cartesian_pose()
            self.X_0 = self.X.copy()
            self.X_d = self.X.copy()
            return True
        else:
            print("✗ 移动超时 - 运动可能未完成")
            return False
    
    def calibrate_force_sensors(self):
        """标定力传感器零点"""
        print("正在标定力传感器...")
        
        calibration_samples = []  
        sample_count = 200  
        
        for i in range(sample_count):
            try:
                feedback = self.base_cyclic.RefreshFeedback()
                torques = []
                for j in range(self.actuator_count):
                    torques.append(feedback.actuators[j].torque)
                calibration_samples.append(torques)
                time.sleep(0.01)  
                
                if i % 50 == 0:  
                    print(f"标定进度: {i/sample_count*100:.0f}%")
                    
            except Exception as e:
                print(f"标定错误: {e}")
                return False
        
        # 计算零点偏移
        samples_array = np.array(calibration_samples)
        self.torque_bias = np.median(samples_array, axis=0)
        
        noise_std = np.std(samples_array, axis=0)
        self.force_threshold = max(2.0, 3 * np.mean(noise_std))
        
        self.bias_calibrated = True
        print("力传感器标定完成")
        print(f"力矩偏移: {self.torque_bias}")
        print(f"力检测阈值: {self.force_threshold:.2f}")
        return True
    
    def check_for_end_or_abort(self, e):
        """动作完成回调函数"""
        def check(notification, e=e):
            if (notification.action_event == Base_pb2.ACTION_END or 
                notification.action_event == Base_pb2.ACTION_ABORT):
                e.set()
        return check
    
    def initialize_control(self):
        """
        初始化变阻抗控制系统
        现在包含遵循理论框架的离线配置文件验证
        """
        if self.is_initialized:
            print("控制系统已经初始化")
            return True
        
        print("正在初始化基于Lyapunov稳定性的变阻抗控制...")
        
        # 离线配置文件验证
        print("\n=== 离线稳定性验证阶段 ===")
        if not self.offline_profile_verification_and_setup(task_duration=15.0):
            print("没有验证稳定的配置文件无法继续")
            return False
        
        # 物理系统初始化
        if not self.move_to_initial_position():
            return False
        
        # 传感器标定
        if not self.calibrate_force_sensors():
            return False
        
        # 获取初始状态反馈
        try:
            self.base_feedback = self.base_cyclic.RefreshFeedback()
        except Exception as e:
            print(f"获取初始反馈失败: {e}")
            return False
        
        # 初始化关节状态
        for i in range(self.actuator_count):
            raw_angle = self.base_feedback.actuators[i].position
            self.q[i] = self.normalize_joint_angle(raw_angle)  
            self.q_dot[i] = self.base_feedback.actuators[i].velocity
        
        # 期望轨迹与当前状态一致
        self.get_cartesian_pose()
        self.X_d = self.X.copy()   
        self.X_d_dot = np.zeros(self.cartesian_dof)   
        self.X_d_ddot = np.zeros(self.cartesian_dof)  
        print(f"期望位置初始化为当前位置: {self.X_d}")
        
        # 初始化控制命令
        for i in range(self.actuator_count):
            self.base_command.actuators[i].flags = 1  
            self.base_command.actuators[i].position = self.q[i]
        
        # 设置低层伺服模式
        base_servo_mode = Base_pb2.ServoingModeInformation()
        base_servo_mode.servoing_mode = Base_pb2.LOW_LEVEL_SERVOING
        self.base.SetServoingMode(base_servo_mode)
        print("已切换到低层伺服模式 - 机器人现在接受实时命令")
        
        # 发送初始控制命令
        try:
            self.base_feedback = self.base_cyclic.Refresh(self.base_command, 0, self.sendOption)
            print("初始控制命令已发送")
        except Exception as e:
            print(f"发送初始命令失败: {e}")
            return False
        
        # 系统稳定等待
        time.sleep(0.5)
        print("系统稳定等待完成")
        
        self.is_initialized = True
        print("变阻抗控制系统初始化成功！")
        return True
    
    def start_control(self):
        """启动控制循环"""
        if not self.is_initialized:
            print("请先初始化控制系统")
            return False
            
        if self.control_running:
            print("控制已在运行中")
            return True
        
        # 启动控制线程
        self.kill_thread = False
        self.control_thread = threading.Thread(target=self.control_loop)
        self.control_thread.daemon = True
        self.control_thread.start()
        
        print("✓ 变阻抗控制已启动！")
        return True
    
    def control_loop(self):
        """主控制循环 - 实时执行变阻抗控制"""
        self.control_running = True
        print("\n" + "="*60)
        print("基于Lyapunov稳定性的变阻抗控制已激活！")
        print("按 'q' 停止控制")
        print("="*60)
        
        cycle_count = 0  
        last_print_time = time.time()  
        last_time = time.time()  
        
        while not self.kill_thread:  
            current_time = time.time()
            dt = current_time - last_time
            
            if dt >= self.control_rate:  
                last_time = current_time
                
                try:
                    # 更新关节状态
                    for i in range(self.actuator_count):
                        raw_angle = self.base_feedback.actuators[i].position
                        self.q[i] = self.normalize_joint_angle(raw_angle)  
                        self.q_dot[i] = self.base_feedback.actuators[i].velocity
                    
                    # 更新笛卡尔状态
                    self.get_cartesian_pose()
                    self.estimate_cartesian_velocity(dt)
                    
                    # 估算外部交互力
                    self.estimate_external_wrench()
                    
                    # 变阻抗控制律
                    self.variable_impedance_control_law(dt)
                    
                    # 关节空间控制映射
                    self.joint_space_control_law(dt)
                    
                    # 更新通信帧ID
                    self.base_command.frame_id = (self.base_command.frame_id + 1) % 65536
                    for i in range(self.actuator_count):
                        self.base_command.actuators[i].command_id = self.base_command.frame_id
                    
                    # 发送控制命令
                    self.base_feedback = self.base_cyclic.Refresh(self.base_command, 0, self.sendOption)
                    cycle_count += 1
                    
                except Exception as e:
                    print(f"控制循环错误: {e}")
                
                # 定期状态监控输出
                if current_time - last_print_time > 2.0:  
                    last_print_time = current_time
                    
                    V1, V2 = self.compute_lyapunov_functions()
                    
                    force_mag = np.linalg.norm(self.F_ext[:3])
                    vel_mag = np.linalg.norm(self.X_dot)
                    
                    print(f"\n--- 变阻抗控制状态监控 ---")
                    print(f"任务阶段: {self.task_phase}")
                    print(f"检测到交互: {self.interaction_detected}")
                    print(f"外部力: {force_mag:.3f}N, 速度: {vel_mag:.4f}m/s")
                    print(f"Lyapunov V1: {V1:.6f}, V2: {V2:.6f}")
                    print(f"稳定性违规: {self.stability_violations}")
                    print(f"刚度K对角: {np.diag(self.K_t)[:3]}")
                    print(f"阻尼D对角: {np.diag(self.D_t)[:3]}")
                    
                    cycle_count = 0
        
        self.control_running = False
        print("\n变阻抗控制已停止")
    
    def stop_control(self):
        """停止控制系统"""
        if not self.control_running:
            print("控制未在运行")
            return
        
        print("正在停止变阻抗控制...")
        self.kill_thread = True
        
        if self.control_thread:
            self.control_thread.join(timeout=5.0)
        
        # 返回单层伺服模式
        base_servo_mode = Base_pb2.ServoingModeInformation()
        base_servo_mode.servoing_mode = Base_pb2.SINGLE_LEVEL_SERVOING
        self.base.SetServoingMode(base_servo_mode)
        
        print("✓ 变阻抗控制已停止")


def show_menu():
    """显示用户菜单"""
    print("\n" + "="*50)
    print("       变阻抗控制器 - 用户界面")
    print("="*50)
    print("i - 初始化控制系统")
    print("s - 启动变阻抗控制")  
    print("q - 停止控制")
    print("h - 显示帮助")
    print("exit - 退出程序")
    print("="*50)


def main():
    """主函数 - 现在包含完整的用户交互界面"""
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import utilities
    
    parser = argparse.ArgumentParser(description="基于Lyapunov稳定性的变阻抗控制器")
    parser.add_argument("--debug", action="store_true", help="调试模式")
    args = utilities.parseConnectionArguments(parser)
    
    with utilities.DeviceConnection.createTcpConnection(args) as router:
        with utilities.DeviceConnection.createUdpConnection(args) as router_real_time:
            
            controller = VariableImpedanceController(router, router_real_time)
            
            print("\n" + "="*70)
            print("基于Lyapunov稳定性的变阻抗控制器")
            print("="*70)
            print("功能特点:")
            print("  • 时变刚度K(t)和阻尼D(t)控制")
            print("  • Lyapunov稳定性验证（V1和V2函数）")
            print("  • 实时稳定性条件监控")
            print("  • 状态无关稳定性约束")
            print("  • 自动安全模式激活")
            print("  • 基于任务的阻抗自适应")
            print("="*70)
            
            # 显示菜单
            show_menu()
            
            # 主交互循环
            while True:
                try:
                    user_input = input("\n请输入命令: ").strip().lower()
                    
                    if user_input == 'exit':
                        print("正在退出...")
                        if controller.control_running:
                            controller.stop_control()
                        break
                    
                    elif user_input == 'h':
                        show_menu()
                    
                    elif user_input == 'i':
                        print("\n开始初始化控制系统...")
                        print("⚠️ 警告：此操作可能导致机械臂运动")
                        confirm = input("确认继续? (y/N): ").strip().lower()
                        
                        if confirm == 'y':
                            if controller.initialize_control():
                                print("✓ 控制系统初始化成功")
                            else:
                                print("✗ 控制系统初始化失败")
                        else:
                            print("初始化已取消")
                    
                    elif user_input == 's':
                        if not controller.is_initialized:
                            print("❌ 请先初始化控制系统 (输入 'i')")
                            continue
                            
                        print("\n准备启动变阻抗控制...")
                        print("⚠️ 警告：机械臂将开始执行阻抗控制")
                        print("⚠️ 确保周围安全，按 'q' 可随时停止")
                        confirm = input("确认启动? (y/N): ").strip().lower()
                        
                        if confirm == 'y':
                            if controller.start_control():
                                print("变阻抗控制已激活！输入 'q' 停止控制")
                                # 进入控制监控模式
                                while controller.control_running:
                                    try:
                                        stop_input = input().strip().lower()
                                        if stop_input == 'q':
                                            controller.stop_control()
                                            break
                                    except KeyboardInterrupt:
                                        print("\n检测到键盘中断，停止控制")
                                        controller.stop_control()
                                        break
                            else:
                                print("✗ 变阻抗控制启动失败")
                        else:
                            print("启动已取消")
                    
                    elif user_input == 'q':
                        if controller.control_running:
                            controller.stop_control()
                        else:
                            print("控制未在运行")
                    
                    else:
                        print(f"未知命令: '{user_input}'")
                        print("输入 'h' 查看帮助")
                
                except KeyboardInterrupt:
                    print("\n\n检测到键盘中断")
                    if controller.control_running:
                        print("正在停止控制...")
                        controller.stop_control()
                    break
                
                except Exception as e:
                    print(f"发生错误: {e}")
                    if controller.control_running:
                        print("为安全起见，停止控制")
                        controller.stop_control()
            
            return 0


if __name__ == "__main__":
    exit(main())