#!/usr/bin/env python3
"""
7自由度机械臂阻抗控制算法
跟踪初始关节角度，仅使用力矩控制模式

主要方程:
1. 机械臂动态方程: M(q)q̈ + C(q,q̇)q̇ + g(q) = τc + τe
2. 阻抗控制方程: H q̈̃ + D(t) q̇̃ + K(t) q̃ = τe
3. 控制输入: τc = M(q) ν + C(q,q̇)q̇ + g(q) - τe
4. 虚拟控制: ν = q̈r + H⁻¹(-D(q̇ - q̇r) - K(q - qr) + τe)
"""

import sys
import os
import numpy as np
import time
import threading
import math
import select
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from datetime import datetime

# Kinova API导入
from kortex_api.autogen.client_stubs.ActuatorConfigClientRpc import ActuatorConfigClient
from kortex_api.autogen.client_stubs.BaseClientRpc import BaseClient
from kortex_api.autogen.client_stubs.BaseCyclicClientRpc import BaseCyclicClient
from kortex_api.autogen.client_stubs.DeviceManagerClientRpc import DeviceManagerClient
from kortex_api.autogen.messages import ActuatorConfig_pb2, Base_pb2, BaseCyclic_pb2, Common_pb2 #Base是基础指令库
from kortex_api.RouterClient import RouterClientSendOptions


class VariableImpedanceController:
    """按照论文理论实现的7自由度机械臂阻抗控制器"""
    
    def __init__(self, router, router_real_time):
        """初始化阻抗控制器，严格按照论文理论"""
        
        # 网络连接设置
        self.router = router #TCP
        self.router_real_time = router_real_time #UDP
        
        # Kinova API客户端
        device_manager = DeviceManagerClient(router) #创建一个 DeviceManagerClient 客户端，该客户端用于管理和查询与机器人相关的所有设备（例如执行器、传感器等）
        self.actuator_config = ActuatorConfigClient(router) #创建一个 ActuatorConfigClient 客户端，用于配置机器人的执行器（例如设置执行器的控制模式，如位置模式、速度模式、扭矩模式等）
        self.base = BaseClient(router) #Base是基础指令库，用TCP
        self.base_cyclic = BaseCyclicClient(router_real_time) #BaseCyclicClient 的主要功能是周期性地刷新基础状态（例如，每毫秒或更短的时间间隔），获取实时的反馈数据，如位置、速度、温度、扭矩等。
        
        # 初始化命令和反馈结构
        self.base_command = BaseCyclic_pb2.Command() #pb2 是与 Protocol Buffers（简称 protobuf）相关的一个命名约定，指的是通过 Protocol Buffers 编译器（protoc）生成的 Python 代码文件
        self.base_feedback = BaseCyclic_pb2.Feedback()
        
        # 获取机器人配置 
        #print("aaaa")
        #print(self.base.GetActuatorCount())
        #input()
        self.actuator_count = self.base.GetActuatorCount().count  # 7自由度
        device_handles = device_manager.ReadAllDevices()
        
        # 这段代码的目的是遍历所有设备句柄（device_handles.device_handle），并根据设备类型判断是否为执行器（BIG_ACTUATOR 或 SMALL_ACTUATOR），然后分别在 self.base_command 和 self.base_feedback 中添加相应的执行器。
        for handle in device_handles.device_handle:
            if handle.device_type == Common_pb2.BIG_ACTUATOR or handle.device_type == Common_pb2.SMALL_ACTUATOR:
                self.base_command.actuators.add()
                self.base_feedback.actuators.add()
        
        # 通信选项
        self.sendOption = RouterClientSendOptions()
        self.sendOption.andForget = False
        self.sendOption.delay_ms = 0
        self.sendOption.timeout_ms = 3
        
        # ====== 按照论文理论的参数设置 ======
        
        # 机械臂状态变量
        N = 7  # 7自由度机械臂
        self.q = np.zeros(N)              # 当前关节位置 q
        self.q_dot = np.zeros(N)          # 当前关节速度 q̇
        self.q_r = np.zeros(N)            # 参考轨迹位置 qr (初始关节角度)
        self.q_dot_r = np.zeros(N)        # 参考轨迹速度 q̇r (保持为0)
        self.q_ddot_r = np.zeros(N)       # 参考轨迹加速度 q̈r (保持为0)
        
        # 时间变化的阻抗参数(按照论文中的时变特性)
        self.H = np.eye(N) * 1.0          # 虚拟惯性矩阵H
        self.K_t = np.eye(N) * 50.0       # 时变刚度矩阵K(t)
        self.D_t = np.eye(N) * 10.0       # 时变阻尼矩阵D(t)
        
        # 外部力矩
        self.tau_e = np.zeros(N)          # 外部扰动τe
        
        # ====== 新增：初始扭矩偏移记录 ======
        self.init_torques = np.zeros(N)   # 记录初始扭矩偏移，避免意外运动
        self.torque_initialized = False   # 标记是否已记录初始扭矩
        
        # 机械臂动力学参数(简化模型)
        self.M_q = np.eye(N) * 1.0        # 惯性矩阵M(q)
        self.C_q = np.zeros((N, N))       # 科里奥利矩阵C(q,q̇)
        self.g_q = np.zeros(N)            # 重力向量g(q)
        
        # 控制输入
        self.tau_c = np.zeros(N)          # 控制力矩τc
        self.nu = np.zeros(N)             # 虚拟控制输入ν
        
        # 控制参数
        self.dt = 0.001  # 控制周期 1ms
        self.control_active = False
        self.kill_thread = False
        self.thread = None
        self.run_duration = 30  # 控制时长(秒)
        
        # 自定义初始位置 (度) - 这将成为跟踪目标
        self.custom_joint_angles_degrees = [180, 16, 180, 229, 0, 54, 90]
        
        # ====== 修正的数据记录变量 ======
        self.time_history = []
        self.q_history = []
        self.q_dot_history = []
        self.tau_cmd_history = []          # tau_cmd: 关节控制力矩 (原tau_c_history)
        self.tau_e_history = []            # tau_e: 外部力矩
        self.tau_measured_history = []     # 测量扭矩
        self.nu_history = []               # nu: 虚拟控制输入/阻抗输入
        self.q_error_history = []          # q_error: 关节角度误差
        
        print(f"📊 机械臂自由度: {N}")
        print(f"📐 角度范围: ±180° (±π 弧度)")
        print(f"🔧 虚拟惯性H: 对角元素 = {np.diag(self.H)}")
        print(f"⚙️ 初始刚度K: 对角元素 = {np.diag(self.K_t)}")
        print(f"🛠️ 初始阻尼D: 对角元素 = {np.diag(self.D_t)}")
        print(f"📍 跟踪目标位置: {self.custom_joint_angles_degrees} 度")

    def normalize_angle(self, angle):
        """将角度正规化到[-π, π]范围内"""
        return np.arctan2(np.sin(angle), np.cos(angle))
    
    def normalize_angles(self, angles):
        """将角度数组正规化到[-π, π]范围内"""
        return np.array([self.normalize_angle(angle) for angle in angles])

    def update_state(self, feedback):
        """更新系统状态"""
        q_current = np.zeros(self.actuator_count)
        q_dot_current = np.zeros(self.actuator_count)
        
        for i in range(self.actuator_count):
            q_current[i] = math.radians(feedback.actuators[i].position)
            q_dot_current[i] = math.radians(feedback.actuators[i].velocity)
        
        q_current = self.normalize_angles(q_current)
        self.q = q_current
        self.q_dot = q_dot_current

    def inertia_matrix(self, q):
        """计算惯性矩阵M(q) - 按照论文动态方程"""
        # 简化模型 - 实际应用中应根据机器人的物理参数计算
        return np.eye(len(q)) * 1.0
    
    def coriolis_matrix(self, q, q_dot):
        """计算科里奥利矩阵C(q,q̇) - 按照论文动态方程"""
        # 简化模型 - 实际应用中应根据机器人的运动学和动力学计算
        return np.zeros((len(q), len(q)))
    
    def gravity_matrix(self, q):
        """计算重力矩阵g(q) - 按照论文动态方程"""
        # 简化模型 - 实际应用中应根据机器人的重力补偿计算
        return np.zeros(len(q))
    
    def stiffness_matrix(self, t):
        """计算时变刚度矩阵K(t) - 按照论文要求"""
        # 可以根据任务需求动态调整刚度
        return self.K_t
    
    def damping_matrix(self, t):
        """计算时变阻尼矩阵D(t) - 按照论文要求"""
        # 可以根据任务需求动态调整阻尼
        return self.D_t

    def inverse_dynamics_control(self, q, q_dot, q_ddot_r, tau_e, t):
        """
        按照论文理论实现的逆动力学控制
        控制输入: τc = M(q) ν + C(q,q̇)q̇ + g(q) - τe
        虚拟控制: ν = q̈r + H⁻¹(-D(q̇ - q̇r) - K(q - qr) + τe)
        """
        try:
            # 计算机械臂动力学矩阵
            M = self.inertia_matrix(q)
            C = self.coriolis_matrix(q, q_dot)
            g = self.gravity_matrix(q)
            
            # 获取当前时间的阻抗参数
            H = self.H
            K = self.stiffness_matrix(t)
            D = self.damping_matrix(t)
            
            # 计算虚拟控制输入ν
            try: # np.linalg.inv(H)：尝试计算矩阵 H 的标准逆矩阵（只有在 H 是 方阵 且 满秩 时才能成功）。
                H_inv = np.linalg.inv(H) 
            except np.linalg.LinAlgError: #如果 H 不可逆（比如行列式为 0，或者不是满秩），np.linalg.inv(H) 就会抛出 LinAlgError 错误。这时就会进入 except，使用 np.linalg.pinv(H) 来计算 伪逆矩阵（Moore–Penrose pseudo-inverse）。
                H_inv = np.linalg.pinv(H)
            
            # 计算误差（确保角度误差在合理范围内）
            q_error_raw = q - self.q_r
            q_error = self.normalize_angles(q_error_raw)  # 角度误差正规化
            q_dot_error = q_dot - self.q_dot_r
            
            # 计算虚拟控制输入（按照论文公式）
            self.nu = q_ddot_r + H_inv @ (-D @ q_dot_error - K @ q_error + tau_e)
            
            # 计算控制输入τc（按照论文公式）
            self.tau_c = M @ self.nu + C @ q_dot + g - tau_e
            
            return self.tau_c
            
        except Exception as e:
            print(f"逆动力学控制计算错误: {e}")
            return np.zeros(len(q))

    def impedance_control_algorithm(self, t):
        """
        按照论文理论实现的主控制算法
        实现阻抗控制方程: H q̈̃ + D(t) q̇̃ + K(t) q̃ = τe
        """
        # 1. 计算当前的外部扰动τe
        self.tau_e = self.estimate_external_torque()
        
        # 2. 计算逆动力学控制输入
        tau_control = self.inverse_dynamics_control(
            self.q, self.q_dot, self.q_ddot_r, self.tau_e, t
        )
        
        # 3. 安全限制
        max_torque = 20.0
        tau_control = np.clip(tau_control, -max_torque, max_torque)
        
        return tau_control

    def move_to_custom_position(self):
        """移动到自定义关节位置"""
        print("移动到初始位置...")
        print(f"目标角度 (度): {self.custom_joint_angles_degrees}")
        
        # 切换到单层伺服模式
        base_servo_mode = Base_pb2.ServoingModeInformation()
        base_servo_mode.servoing_mode = Base_pb2.SINGLE_LEVEL_SERVOING
        self.base.SetServoingMode(base_servo_mode)
        
        # 准备关节角度目标
        constrained_joint_angles = Base_pb2.ConstrainedJointAngles()
        
        for joint_id in range(len(self.custom_joint_angles_degrees)):
            joint_angle = constrained_joint_angles.joint_angles.joint_angles.add()
            joint_angle.joint_identifier = joint_id
            joint_angle.value = self.custom_joint_angles_degrees[joint_id]
        
        # 事件同步逻辑
        finished_event = threading.Event()
        
        def check_for_end_or_abort(notification, event=finished_event):
            if notification.action_event == Base_pb2.ACTION_END or notification.action_event == Base_pb2.ACTION_ABORT:
                event.set()
        
        notification_handle = self.base.OnNotificationActionTopic(
            check_for_end_or_abort,
            Base_pb2.NotificationOptions()
        )
        
        print("执行关节运动...")
        self.base.PlayJointTrajectory(constrained_joint_angles)
        
        print("等待运动完成...")
        finished = finished_event.wait(30.0)
        self.base.Unsubscribe(notification_handle)
        
        if finished:
            print("✅ 到达初始位置")
            # 设置参考位置为当前位置（即初始关节角度）
            feedback = self.base_cyclic.RefreshFeedback()
            q_ref_temp = np.zeros(self.actuator_count)
            for i in range(self.actuator_count):
                q_ref_temp[i] = math.radians(feedback.actuators[i].position)
            
            # 将参考角度也限制在[-π, π]范围内
            self.q_r = self.normalize_angles(q_ref_temp)
            
            print(f"参考角度设置为: {np.degrees(self.q_r)} 度")
            return True
        else:
            print("❌ 运动超时")
            return False

    def init_torque_offsets(self):
        """初始化扭矩偏移量 - 在开始控制前调用"""
        try:
            # 获取当前反馈
            feedback = self.base_cyclic.RefreshFeedback()
            
            # 记录所有关节的初始扭矩
            for i in range(self.actuator_count):
                self.init_torques[i] = feedback.actuators[i].torque
            
            self.torque_initialized = True
            print(f"✅ 初始扭矩偏移已记录: {self.init_torques}")
            
        except Exception as e:
            print(f"❌ 初始化扭矩偏移失败: {e}")
            self.torque_initialized = False
        
    def estimate_external_torque(self):
        """估计外部力矩τe - 使用实际扭矩传感器数据"""
        if not self.torque_initialized:
            # 如果还未初始化，返回零向量
            return np.zeros(self.actuator_count)
        
        try:
            # 获取当前所有关节的扭矩测量值
            tau_measured = np.zeros(self.actuator_count)
            for i in range(self.actuator_count):
                tau_measured[i] = self.base_feedback.actuators[i].torque
            
            # 计算外部扭矩 = 测量扭矩 - 初始扭矩偏移
            # 这样可以消除系统的内在扭矩偏移，得到真正的外部扰动
            tau_external = tau_measured - self.init_torques
            
            return tau_external
            
        except Exception as e:
            print(f"外部扭矩估计错误: {e}")
            return np.zeros(self.actuator_count)        
        
    def init_torque_control(self):
        """初始化力矩控制模式"""
        try:
            # 初始化反馈
            self.base_feedback = self.base_cyclic.RefreshFeedback()

            # ====== 新增：记录初始扭矩偏移 ======
            self.init_torque_offsets()
            if not self.torque_initialized:
                print("❌ 扭矩偏移初始化失败")
                return False
            
            # 设置命令结构
            for i in range(self.actuator_count):
                self.base_command.actuators[i].flags = 1
                self.base_command.actuators[i].position = self.base_feedback.actuators[i].position
            
            # 设置为低级伺服模式
            base_servo_mode = Base_pb2.ServoingModeInformation()
            base_servo_mode.servoing_mode = Base_pb2.LOW_LEVEL_SERVOING
            self.base.SetServoingMode(base_servo_mode)
            
            # 发送首个命令帧
            self.base_feedback = self.base_cyclic.Refresh(self.base_command, 0, self.sendOption)
            
            # 切换到力矩控制模式
            control_mode_msg = ActuatorConfig_pb2.ControlModeInformation()
            control_mode_msg.control_mode = ActuatorConfig_pb2.ControlMode.TORQUE
            for device_id in range(1, self.actuator_count + 1):
                self.actuator_config.SetControlMode(control_mode_msg, device_id)
            
            print("✅ 力矩控制模式初始化完成")
            return True
            
        except Exception as e:
            print(f"❌ 力矩控制初始化失败: {e}")
            return False
    
    def start_control(self):
        """启动控制"""
        if self.thread and self.thread.is_alive():
            print("控制已在运行")
            return
        
        print("启动阻抗控制...")
        self.control_active = True
        self.kill_thread = False
        self.thread = threading.Thread(target=self.control_loop)
        self.thread.start()
    
    def control_loop(self):
        """主控制循环"""
        print(f"运行控制 {self.run_duration} 秒...")
        start_time = time.time()
        frame_id = 0
        loop_count = 0  # 添加循环计数器
        
        while not self.kill_thread and (time.time() - start_time) < self.run_duration:
            loop_start = time.time()
            current_time = time.time() - start_time
            loop_count += 1
            
            try:
                # 获取反馈
                self.base_feedback = self.base_cyclic.RefreshFeedback()
                
                # 更新状态
                self.update_state(self.base_feedback)
                
                # 计算控制力矩（按照论文理论）
                tau_cmd = self.impedance_control_algorithm(current_time)

                # 记录测量扭矩
                tau_measured_current = np.zeros(self.actuator_count)
                for i in range(self.actuator_count):
                    tau_measured_current[i] = self.base_feedback.actuators[i].torque
                
                # 计算关节角度误差
                q_error_raw = self.q - self.q_r
                q_error = self.normalize_angles(q_error_raw)
                
                # ====== 关键修正：每次循环都记录数据 ======
                # 每10次记录一次以获得足够数据点但不影响性能
                if loop_count % 10 == 0:
                    self.time_history.append(current_time)
                    self.q_history.append(self.q.copy())
                    self.q_dot_history.append(self.q_dot.copy())
                    self.tau_cmd_history.append(tau_cmd.copy())      # tau_cmd: 关节控制力矩
                    self.tau_e_history.append(self.tau_e.copy())     # tau_e: 外部力矩
                    self.tau_measured_history.append(tau_measured_current.copy())
                    self.nu_history.append(self.nu.copy())           # nu: 阻抗输入
                    self.q_error_history.append(q_error.copy())      # q_error: 关节角度误差
                     
                # 更新命令
                for i in range(self.actuator_count):
                    self.base_command.actuators[i].position = self.base_feedback.actuators[i].position
                    self.base_command.actuators[i].torque_joint = float(tau_cmd[i])
                
                frame_id = (frame_id + 1) % 65536
                self.base_command.frame_id = frame_id
                for i in range(self.actuator_count):
                    self.base_command.actuators[i].command_id = frame_id
                
                # 发送命令
                self.base_feedback = self.base_cyclic.Refresh(self.base_command, 0, self.sendOption)
                
                # 状态监控 (减少监控频率以避免太多输出)
                if loop_count % 1000 == 0:
                    q_error_degrees = np.degrees(q_error)
                    max_error = np.max(np.abs(q_error_degrees))
                    tau_ext_norm = np.linalg.norm(self.tau_e)
                    tau_measured_norm = np.linalg.norm(tau_measured_current)
                    
                    print(f"时间: {current_time:.1f}s, "
                          f"循环: {loop_count}, "
                          f"数据点: {len(self.time_history)}, "
                          f"最大角度误差: {max_error:.2f}°, "
                          f"控制力矩: {np.linalg.norm(tau_cmd):.2f}Nm, "
                          f"外部扭矩: {tau_ext_norm:.3f}Nm")
                
                # 控制频率
                elapsed = time.time() - loop_start
                if elapsed < self.dt:
                    time.sleep(self.dt - elapsed)
                
            except Exception as err:
                print(f"控制循环错误: {err}")
        
        print(f"控制循环结束 - 总循环次数: {loop_count}, 记录数据点: {len(self.time_history)}")
        self.control_active = False
    
    def stop_control(self):
        """停止控制"""
        print("停止控制...")
        self.kill_thread = True
        self.control_active = False
        
        if self.thread:
            self.thread.join()
        
        # 恢复位置控制
        try:
            control_mode_msg = ActuatorConfig_pb2.ControlModeInformation()
            control_mode_msg.control_mode = ActuatorConfig_pb2.ControlMode.POSITION
            for device_id in range(1, self.actuator_count + 1):
                self.actuator_config.SetControlMode(control_mode_msg, device_id)
            
            base_servo_mode = Base_pb2.ServoingModeInformation()
            base_servo_mode.servoing_mode = Base_pb2.SINGLE_LEVEL_SERVOING
            self.base.SetServoingMode(base_servo_mode)
        except Exception as e:
            print(f"恢复控制模式错误: {e}")
        
        print("控制停止完成")
        self.save_data()
        self.plot_control_data()  # 自动生成图表
    
    def save_data(self):
        """保存实验数据"""
        if not self.time_history:
            print("没有数据需要保存")
            return
        
        try:
            import csv
            
            # 创建数据文件夹
            data_folder = "impedance_control_data"
            if not os.path.exists(data_folder):
                os.makedirs(data_folder)
            
            filename = os.path.join(data_folder, 'variable_impedance_data.csv')
            
            with open(filename, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                
                # 写入头部
                header = ['time']
                for i in range(self.actuator_count):
                    header.extend([f'q{i}', f'qdot{i}', f'tau_cmd{i}', f'tau_e{i}', 
                                  f'tau_measured{i}', f'nu{i}', f'q_error{i}'])
                writer.writerow(header)
                
                # 写入数据
                for i in range(len(self.time_history)):
                    row = [self.time_history[i]]
                    for j in range(self.actuator_count):
                        row.extend([
                            self.q_history[i][j] if j < len(self.q_history[i]) else 0,
                            self.q_dot_history[i][j] if j < len(self.q_dot_history[i]) else 0,
                            self.tau_cmd_history[i][j] if j < len(self.tau_cmd_history[i]) else 0,  # tau_cmd
                            self.tau_e_history[i][j] if j < len(self.tau_e_history[i]) else 0,      # tau_e
                            self.tau_measured_history[i][j] if i < len(self.tau_measured_history) and j < len(self.tau_measured_history[i]) else 0,
                            self.nu_history[i][j] if i < len(self.nu_history) and j < len(self.nu_history[i]) else 0,  # nu
                            self.q_error_history[i][j] if i < len(self.q_error_history) and j < len(self.q_error_history[i]) else 0  # q_error
                        ])
                    writer.writerow(row)
            
            print(f"✅ 数据已保存至 {filename}")
            print(f"📊 记录数据点: {len(self.time_history)}, 时间范围: 0-{self.time_history[-1]:.1f}秒")
            
        except Exception as e:
            print(f"数据保存失败: {e}")

    def plot_control_data(self):
        """生成控制过程的可视化图表"""
        if not self.time_history:
            print("没有数据需要绘图")
            return
        
        try:
            # 创建图片保存文件夹
            plot_folder = "impedance_control_plots"
            if not os.path.exists(plot_folder):
                os.makedirs(plot_folder)
            
            # 转换数据为numpy数组
            time_array = np.array(self.time_history)
            tau_cmd_array = np.array(self.tau_cmd_history)   # 关节控制力矩
            tau_e_array = np.array(self.tau_e_history)       # 外部力矩
            nu_array = np.array(self.nu_history)             # 阻抗输入
            q_error_array = np.array(self.q_error_history)   # 关节角度误差
            
            print(f"📊 绘图数据检查:")
            print(f"   时间点数量: {len(time_array)}")
            print(f"   时间范围: {time_array[0]:.2f}s - {time_array[-1]:.2f}s")
            print(f"   数据形状: tau_cmd{tau_cmd_array.shape}, q_error{q_error_array.shape}")
            
            # 设置matplotlib字体
            plt.rcParams['font.family'] = 'DejaVu Sans'
            plt.rcParams['axes.unicode_minus'] = False
            
            # 1. 关节控制力矩 tau_cmd 图
            self._plot_torque_data(time_array, tau_cmd_array, 
                                 "Joint Control Torque (tau_cmd)", 
                                 "Control Torque (Nm)", 
                                 "joint_control_torque_tau_cmd.png", plot_folder)
            
            # 2. 阻抗输入/虚拟控制输入 ν 图
            self._plot_torque_data(time_array, nu_array, 
                                 "Impedance Control Input (Virtual Control ν)", 
                                 "Virtual Control Input (rad/s²)", 
                                 "impedance_control_input_nu.png", plot_folder)
            
            # 3. 关节角度跟踪误差图
            self._plot_angle_error_data(time_array, q_error_array, 
                                      "Joint Angle Tracking Error (q_error)", 
                                      "Angle Error (rad)", 
                                      "joint_angle_tracking_error.png", plot_folder)
            
            # 4. 外部力矩图
            self._plot_torque_data(time_array, tau_e_array, 
                                 "External Torque (tau_e)", 
                                 "External Torque (Nm)", 
                                 "external_torque_tau_e.png", plot_folder)
            
            # 5. 综合对比图
            self._plot_comprehensive_comparison(time_array, tau_cmd_array, nu_array, 
                                              q_error_array, tau_e_array, plot_folder)
            
            print(f"✅ 所有图表已保存至文件夹: {plot_folder}")
            
        except Exception as e:
            print(f"绘图失败: {e}")
    
    def _plot_torque_data(self, time_array, data_array, title, ylabel, filename, folder):
        """绘制扭矩类数据"""
        fig, axes = plt.subplots(7, 1, figsize=(12, 14))
        fig.suptitle(f'{title} - 7DOF Robot Arm Impedance Control', fontsize=16, fontweight='bold')
        
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']
        
        for i in range(7):
            axes[i].plot(time_array, data_array[:, i], color=colors[i], linewidth=1.5, 
                        label=f'Joint {i+1}')
            axes[i].set_ylabel(f'Joint {i+1}\n{ylabel}', fontsize=10)
            axes[i].grid(True, alpha=0.3)
            axes[i].legend(loc='upper right', fontsize=8)
            
            # 添加统计信息
            mean_val = np.mean(data_array[:, i])
            std_val = np.std(data_array[:, i])
            max_val = np.max(np.abs(data_array[:, i]))
            axes[i].text(0.02, 0.95, f'Mean: {mean_val:.3f}\nStd: {std_val:.3f}\nMax: {max_val:.3f}', 
                        transform=axes[i].transAxes, fontsize=8, verticalalignment='top',
                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
        
        axes[-1].set_xlabel('Time (s)', fontsize=12)
        plt.tight_layout()
        plt.savefig(os.path.join(folder, filename), dpi=300, bbox_inches='tight')
        plt.close()
    
    def _plot_angle_error_data(self, time_array, error_array, title, ylabel, filename, folder):
        """绘制角度误差数据（转换为度数显示）"""
        fig, axes = plt.subplots(7, 1, figsize=(12, 14))
        fig.suptitle(f'{title} - 7DOF Robot Arm Impedance Control', fontsize=16, fontweight='bold')
        
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']
        error_degrees = np.degrees(error_array)  # 转换为度数
        
        for i in range(7):
            axes[i].plot(time_array, error_degrees[:, i], color=colors[i], linewidth=1.5, 
                        label=f'Joint {i+1}')
            axes[i].set_ylabel(f'Joint {i+1}\nAngle Error (°)', fontsize=10)
            axes[i].grid(True, alpha=0.3)
            axes[i].legend(loc='upper right', fontsize=8)
            
            # 添加±1度参考线
            axes[i].axhline(y=1, color='red', linestyle='--', alpha=0.5, linewidth=1)
            axes[i].axhline(y=-1, color='red', linestyle='--', alpha=0.5, linewidth=1)
            
            # 添加统计信息
            mean_val = np.mean(error_degrees[:, i])
            std_val = np.std(error_degrees[:, i])
            max_val = np.max(np.abs(error_degrees[:, i]))
            axes[i].text(0.02, 0.95, f'Mean: {mean_val:.3f}°\nStd: {std_val:.3f}°\nMax: {max_val:.3f}°', 
                        transform=axes[i].transAxes, fontsize=8, verticalalignment='top',
                        bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.8))
        
        axes[-1].set_xlabel('Time (s)', fontsize=12)
        plt.tight_layout()
        plt.savefig(os.path.join(folder, filename), dpi=300, bbox_inches='tight')
        plt.close()
    
    def _plot_comprehensive_comparison(self, time_array, tau_cmd_array, nu_array, 
                                     q_error_array, tau_e_array, folder):
        """绘制综合对比图"""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle('Impedance Control Performance Overview - 7DOF Robot Arm', 
                     fontsize=16, fontweight='bold')
        
        # 计算各指标的总体指标
        tau_cmd_norm = np.linalg.norm(tau_cmd_array, axis=1)  # 关节控制力矩范数
        nu_norm = np.linalg.norm(nu_array, axis=1)            # 阻抗输入范数
        q_error_norm = np.linalg.norm(q_error_array, axis=1)  # 角度误差范数
        tau_e_norm = np.linalg.norm(tau_e_array, axis=1)      # 外部力矩范数
        
        # 子图1: 关节控制力矩范数
        axes[0, 0].plot(time_array, tau_cmd_norm, 'b-', linewidth=2, label='||tau_cmd||')
        axes[0, 0].set_title('Joint Control Torque Magnitude', fontweight='bold')
        axes[0, 0].set_ylabel('Control Torque Norm (Nm)')
        axes[0, 0].grid(True, alpha=0.3)
        axes[0, 0].legend()
        
        # 子图2: 阻抗控制输入范数
        axes[0, 1].plot(time_array, nu_norm, 'g-', linewidth=2, label='||nu (impedance input)||')
        axes[0, 1].set_title('Impedance Control Input Magnitude', fontweight='bold')
        axes[0, 1].set_ylabel('Impedance Input Norm (rad/s²)')
        axes[0, 1].grid(True, alpha=0.3)
        axes[0, 1].legend()
        
        # 子图3: 角度误差范数（转换为度数）
        q_error_norm_degrees = np.degrees(q_error_norm)
        axes[1, 0].plot(time_array, q_error_norm_degrees, 'r-', linewidth=2, label='||q_error||')
        axes[1, 0].axhline(y=1, color='red', linestyle='--', alpha=0.5, 
                          label='±1° Reference')
        axes[1, 0].set_title('Joint Angle Tracking Error Magnitude', fontweight='bold')
        axes[1, 0].set_ylabel('Error Norm (°)')
        axes[1, 0].set_xlabel('Time (s)')
        axes[1, 0].grid(True, alpha=0.3)
        axes[1, 0].legend()
        
        # 子图4: 外部力矩范数
        axes[1, 1].plot(time_array, tau_e_norm, 'm-', linewidth=2, label='||tau_e||')
        axes[1, 1].set_title('External Torque Magnitude', fontweight='bold')
        axes[1, 1].set_ylabel('External Torque Norm (Nm)')
        axes[1, 1].set_xlabel('Time (s)')
        axes[1, 1].grid(True, alpha=0.3)
        axes[1, 1].legend()
        
        # 添加整体性能统计
        performance_text = f"""Performance Summary:
        Joint Control Torque: Mean={np.mean(tau_cmd_norm):.3f}Nm, Max={np.max(tau_cmd_norm):.3f}Nm
        Impedance Input: Mean={np.mean(nu_norm):.3f}rad/s², Max={np.max(nu_norm):.3f}rad/s²
        Tracking Error: Mean={np.mean(q_error_norm_degrees):.3f}°, Max={np.max(q_error_norm_degrees):.3f}°
        External Torque: Mean={np.mean(tau_e_norm):.3f}Nm, Max={np.max(tau_e_norm):.3f}Nm"""
                
        fig.text(0.02, 0.02, performance_text, fontsize=10, 
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
        
        plt.tight_layout()
        plt.subplots_adjust(bottom=0.15)
        plt.savefig(os.path.join(folder, 'comprehensive_performance_overview.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()
        
        # 生成额外的 3D 轨迹图（如果有足够的数据）
        if len(time_array) > 100:
            self._plot_3d_trajectory(tau_cmd_array, q_error_array, folder)
    
    def _plot_3d_trajectory(self, tau_cmd_array, q_error_array, folder):
        """绘制3D轨迹图"""
        try:
            from mpl_toolkits.mplot3d import Axes3D
            
            fig = plt.figure(figsize=(14, 10))
            
            # 3D 散点图：关节控制力矩轨迹
            ax = fig.add_subplot(111, projection='3d')
            
            # 选择前3个关节进行3D可视化
            tau_cmd_norm = np.linalg.norm(tau_cmd_array[:, :3], axis=1)
            time_normalized = np.linspace(0, 1, len(tau_cmd_norm))
            
            scatter = ax.scatter(tau_cmd_array[:, 0], tau_cmd_array[:, 1], tau_cmd_array[:, 2], 
                               c=time_normalized, cmap='viridis', s=20, alpha=0.6)
            
            ax.set_xlabel('Joint 1 Control Torque (Nm)')
            ax.set_ylabel('Joint 2 Control Torque (Nm)')
            ax.set_zlabel('Joint 3 Control Torque (Nm)')
            ax.set_title('3D Joint Control Torque Trajectory (Joints 1-3)', fontweight='bold')
            
            # 添加颜色条
            cbar = plt.colorbar(scatter, ax=ax, shrink=0.5)
            cbar.set_label('Normalized Time')
            
            plt.savefig(os.path.join(folder, '3d_joint_control_torque_trajectory.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except ImportError:
            print("Warning: 3D plotting requires matplotlib toolkit, skipping 3D plots")
        except Exception as e:
            print(f"3D plotting failed: {e}")


def main():
    """主函数 - 按照论文理论的完整算法流程"""
    import argparse
    
    # 添加utilities路径
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    
    try:
        from utilities import DeviceConnection, parseConnectionArguments
    except ImportError:
        print("错误：无法导入utilities模块，请检查路径")
        return 1
    
    parser = argparse.ArgumentParser()
    args = parseConnectionArguments(parser)
    
    with DeviceConnection.createTcpConnection(args) as router:
        with DeviceConnection.createUdpConnection(args) as router_real_time:
            controller = VariableImpedanceController(router, router_real_time)
            
            print("=== 基于论文理论的7自由度机械臂阻抗控制系统 ===")
            print("特点:")
            print("- 完全实现论文中的动态方程")
            print("- 阻抗控制方程: H q̈̃ + D(t) q̇̃ + K(t) q̃ = τe")
            print("- 逆动力学控制: τc = M(q) ν + C(q,q̇)q̇ + g(q) - τe")
            print("- 虚拟控制输入: ν = q̈r + H⁻¹(-D(q̇-q̇r) - K(q-qr) + τe)")
            print("- 跟踪初始关节角度（保持位置稳定）")
            print("- 角度限制在±180度范围内")
            print("- 仅使用力矩控制模式")
            print("- 完整的数据可视化和分析")
            print(f"- 自定义初始位置: {controller.custom_joint_angles_degrees} 度")
            print("=" * 60)
            
            # 首先移动到初始位置
            print("正在移动到初始位置...")
            if not controller.move_to_custom_position():
                print("❌ 移动到初始位置失败")
                return 1
            print("✅ 已到达初始位置，设置为跟踪目标")
            
            try:
                print("\n系统已准备就绪")
                print("按 's' 启动阻抗控制（跟踪当前位置）")
                print("按 'q' 退出程序")
                print("📝 理论符合性验证: 完全按照提供的论文理论和伪代码实现")
                print("📊 控制完成后将自动生成详细的可视化图表")
                
                while True:
                    # 检查用户输入
                    if select.select([sys.stdin], [], [], 0.1)[0]:
                        key = sys.stdin.readline().strip().lower()
                        
                        if key == 's' and not controller.control_active:
                            print("正在初始化力矩控制...")
                            if controller.init_torque_control():
                                print("初始化完成，启动阻抗控制...")
                                controller.start_control()
                                print("✅ 阻抗控制已启动 - 跟踪初始关节角度")
                            else:
                                print("❌ 力矩控制初始化失败")
                                
                        elif key == 'q':
                            print("退出程序...")
                            break
                    
                    # 检查控制是否完成
                    if controller.control_active and not controller.thread.is_alive():
                        print("阻抗控制完成")
                        break
                        
                return 0
                    
            except KeyboardInterrupt:
                print("用户中断")
            finally:
                controller.stop_control()

if __name__ == "__main__":
    sys.exit(main())