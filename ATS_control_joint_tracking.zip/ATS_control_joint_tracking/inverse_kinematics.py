import numpy as np

from Kinematic_fcn import Ttrans7

def inverse_kinematics(theta, V_edp, z_tool): #return theta_dot, Sigma
    """
    计算机器人关节角速度并处理奇异位形
    
    参数:
    theta: 7个关节角度的向量
    V_edp: 末端期望速度 [vx, vy, vz, wx, wy, wz]^T (6x1)
    z_tool: 工具长度
    
    返回:
    theta_dot: 关节角速度 (7x1)
    N: 奇异值向量 (6个元素)
    """
    # 假设 Ttrans7 函数已经实现（需要你补充）
    T_trans_0, T_0_7 = Ttrans7(theta)
    
    # 构造 T_7_e 变换矩阵
    T_7_e = np.array([
        [1,  0,  0,  0],
        [0, -1,  0,  0],
        [0,  0, -1, z_tool],
        [0,  0,  0,  1]
    ])
    
    # 计算末端执行器变换矩阵
    T_0_e = T_0_7 @ T_7_e
    P_e = T_0_e[:3, 3] # 末端位置 (3x1),3代指0-3中的第四列
    
    # 初始化雅可比矩阵
    J_ev = np.zeros((3, 7))  # 线速度雅可比
    J_ew = np.zeros((3, 7))  # 角速度雅可比
    
    z_0 = np.array([0, 0, 1])  # z轴方向
    
    for i in range(7):
        # 获取关节i的变换矩阵
        T_0_i = T_trans_0[i, :, :]
        z = T_0_i[:3, :3] @ z_0  # 关节轴方向（世界坐标系）
        
        # 计算关节位置
        p_tilde = T_0_i[:3, 3]  # 关节位置 (3x1)
        p_ei_1 = P_e - p_tilde  # 末端到关节的向量
        
        # 计算线速度雅可比列
        J_ev[:, i] = np.cross(z, p_ei_1)
        
        # 角速度雅可比就是关节轴方向
        J_ew[:, i] = z
    
    # 合并雅可比矩阵 (6x7) 
    J_em = np.vstack([J_ev, J_ew])
    
    # 计算奇异值分解 V_e= J_em^T(J_em*J_em^T)^-1*theta_dot;
    A = J_em @ J_em.T
    U, Sigma, Vt = np.linalg.svd(A)
    V = Vt.T
    
    # 奇异值处理参数
    Zm = 0.08  # 奇异阻尼
    Y = 0.03   # 奇异阈值
    
    # 创建阻尼伪逆
    Sigma_inv = np.zeros_like(Sigma)
    for i in range(len(Sigma)):
        if Sigma[i] < Y:
            Z = Zm * (1 - (Sigma[i] / Y))
        else:
            Z = 0
        # 阻尼奇异值求逆
        Sigma_inv[i] = Sigma[i] / (Sigma[i]**2 + Z**2)
    
    # 创建对角矩阵的逆
    Sigma_inv_mat = np.diag(Sigma_inv)
    
    # 计算加权伪逆
    J_em_wei1 = V @ Sigma_inv_mat @ U.T
    
    # 计算关节角速度
    theta_dot = J_em.T @ J_em_wei1 @ V_edp
    

    return theta_dot, Sigma