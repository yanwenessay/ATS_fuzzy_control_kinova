#! /usr/bin/env python3
# 机器人关节力矩控制程序 - 带角度连续性处理

import sys              # 系统相关操作
import os               # 操作系统接口
import time             # 时间相关功能
import threading        # 多线程支持
import math             # 数学函数库
import select           # I/O多路复用
import numpy as np      # 数值计算库
import matplotlib.pyplot as plt  # 绘图库
plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC']  # 设置中文字体

from control_main import *  # 导入控制算法主模块

# 导入Kortex API相关模块
from kortex_api.autogen.client_stubs.ActuatorConfigClientRpc import ActuatorConfigClient
from kortex_api.autogen.client_stubs.BaseClientRpc import BaseClient
from kortex_api.autogen.client_stubs.BaseCyclicClientRpc import BaseCyclicClient
from kortex_api.autogen.client_stubs.DeviceManagerClientRpc import DeviceManagerClient
from kortex_api.autogen.messages import ActuatorConfig_pb2, Base_pb2, BaseCyclic_pb2, Common_pb2
from kortex_api.RouterClient import RouterClientSendOptions

class AngleUnwrapper:
    """角度连续性处理类 - 解决360度跳跃问题"""
    
    def __init__(self):
        self.previous_angle = None      # 上一次的角度值
        self.cumulative_offset = 0.0    # 累积偏移量（圈数 × 360）
        self.jump_threshold = 180.0     # 跳跃检测阈值（度）
        
    def unwrap_angle(self, current_angle_deg):
        """
        处理角度连续性，消除360度跳跃
        
        Args:
            current_angle_deg: 当前测量的角度（度）
            
        Returns:
            float: 连续的角度值（度）
        """
        if self.previous_angle is None:
            # 第一次调用，直接记录并返回
            self.previous_angle = current_angle_deg
            return current_angle_deg
        
        # 计算与上一次角度的差值
        angle_diff = current_angle_deg - self.previous_angle
        
        # 检测正向跳跃（从高角度跳到低角度，如359° -> 1°）
        if angle_diff < -self.jump_threshold:
            self.cumulative_offset += 360.0
            print(f"🔄 检测到正向角度跳跃: {self.previous_angle:.1f}° -> {current_angle_deg:.1f}°, 累积偏移: {self.cumulative_offset:.1f}°")
        
        # 检测反向跳跃（从低角度跳到高角度，如1° -> 359°）
        elif angle_diff > self.jump_threshold:
            self.cumulative_offset -= 360.0
            print(f"🔄 检测到反向角度跳跃: {self.previous_angle:.1f}° -> {current_angle_deg:.1f}°, 累积偏移: {self.cumulative_offset:.1f}°")
        
        # 更新上一次角度
        self.previous_angle = current_angle_deg
        
        # 返回连续的角度值
        continuous_angle = current_angle_deg + self.cumulative_offset
        return continuous_angle
    
    def reset(self):
        """重置角度连续性处理器"""
        self.previous_angle = None
        self.cumulative_offset = 0.0
        print("✅ 角度连续性处理器已重置")

class TorqueControlSingle:
    """单关节力矩控制类"""

    def __init__(self, router, router_real_time):
        """初始化力矩控制器"""
        # ==========================================================
        # 配置参数：指定要控制的轴 (1=第一轴, 2=第二轴, 3=第三轴, ...)
        self.CONTROL_AXIS = 3  # 修改这里来选择要控制的轴
        # ==========================================================
        
        # 轨迹参数 - 统一在这里定义，避免代码重复
        
        self.torque_value = 0.0      # 初始力矩值为0
        self.run_duration = 20       # 运行时间（秒）
        self.control_active = False  # 控制激活标志

        # 初始化Kortex API客户端
        self.device_manager = DeviceManagerClient(router)           # 设备管理客户端
        self.actuator_config = ActuatorConfigClient(router)         # 执行器配置客户端
        self.base = BaseClient(router)                              # 基础功能客户端
        self.base_cyclic = BaseCyclicClient(router_real_time)       # 循环控制客户端（实时）

        # 初始化命令和反馈消息
        self.base_command = BaseCyclic_pb2.Command()    # 基础命令消息
        self.base_feedback = BaseCyclic_pb2.Feedback()  # 基础反馈消息

        # 读取设备信息
        device_handles = self.device_manager.ReadAllDevices()  # 读取所有设备句柄
        self.actuator_count = self.base.GetActuatorCount().count  # 获取执行器数量

        # 验证指定的轴是否有效
        if self.CONTROL_AXIS < 1 or self.CONTROL_AXIS > self.actuator_count:
            raise ValueError(f"控制轴 {self.CONTROL_AXIS} 超出范围！机器人共有 {self.actuator_count} 个轴")

        # 计算数组索引和设备ID
        self.control_axis_index = self.CONTROL_AXIS - 1  # 数组索引从0开始
        self.control_device_id = self.CONTROL_AXIS       # 设备ID从1开始

        # 为每个执行器添加命令和反馈结构
        for handle in device_handles.device_handle:
            if handle.device_type == Common_pb2.BIG_ACTUATOR or handle.device_type == Common_pb2.SMALL_ACTUATOR:
                self.base_command.actuators.add()   # 添加执行器命令
                self.base_feedback.actuators.add()  # 添加执行器反馈

        # 配置发送选项
        self.sendOption = RouterClientSendOptions()  # 路由器客户端发送选项
        self.sendOption.andForget = False            # 不使用"发送并忘记"模式
        self.sendOption.delay_ms = 0                 # 延迟时间（毫秒）
        self.sendOption.timeout_ms = 3               # 超时时间（毫秒）

        # 线程控制变量
        self.kill_thread = False  # 线程终止标志
        self.thread = None        # 控制线程对象
        
        # 控制器和数据记录
        self.controller = control_main()  # 初始化控制器
        self.time_history     = []        # 时间历史记录
        self.position_history = []        # 位置历史记录（弧度）
        self.torque_history   = []        # 力矩历史记录（牛米）
        self.desired_history  = []        # 期望位置历史记录（弧度）
        self.raw_position_history = []    # 原始位置历史记录（用于调试）

        # 🆕 新增：角度连续性处理器
        self.angle_unwrapper = AngleUnwrapper()

        print(f"✅ 已配置为控制第 {self.CONTROL_AXIS} 轴 (索引: {self.control_axis_index}, 设备ID: {self.control_device_id})")

        self.amplitude_deg = 10.0    # 振幅（度）
        self.frequency_hz = 0.2      # 频率（Hz）
        print(f"   轨迹参数: 振幅={self.amplitude_deg}°, 频率={self.frequency_hz}Hz")
        print(f"🔧 已启用角度连续性处理，跳跃检测阈值: {self.angle_unwrapper.jump_threshold}°")

    def compute_desired_trajectory(self, time_value):
        """
        计算期望轨迹 - 统一的轨迹生成方法
        
        Args:
            time_value: 时间值（秒）或时间数组
            
        Returns:
            tuple: (desired_position_rad, desired_velocity_rad_per_sec)
        """
        amplitude_rad = self.amplitude_deg * math.pi / 180.0    # 振幅转换为弧度
        omega = 2.0 * math.pi * self.frequency_hz               # 角频率
        desired_pos = -0*np.pi+ amplitude_rad * np.sin(omega * time_value)
        desired_vel = amplitude_rad * omega * np.cos(omega * time_value)
            
        return desired_pos, desired_vel
    
    def get_continuous_position(self):
        """
        获取连续的位置角度（处理360度跳跃）
        
        Returns:
            tuple: (continuous_position_deg, raw_position_deg)
        """
        # 获取原始位置反馈
        raw_position_deg = self.base_feedback.actuators[self.control_axis_index].position
        
        # 🆕 使用角度连续性处理器处理跳跃
        continuous_position_deg = self.angle_unwrapper.unwrap_angle(raw_position_deg)
        
        return continuous_position_deg, raw_position_deg

    def example_move_to_start_position(self):
        """移动到起始位置（所有关节角度为0）"""
        # 🆕 移动前重置角度连续性处理器
        self.angle_unwrapper.reset()
        
        # 切换到单层伺服模式
        base_servo_mode = Base_pb2.ServoingModeInformation()          # 创建伺服模式信息
        base_servo_mode.servoing_mode = Base_pb2.SINGLE_LEVEL_SERVOING  # 设置为单层伺服模式
        self.base.SetServoingMode(base_servo_mode)                    # 应用伺服模式
        
        # 准备关节角度目标
        constrained_joint_angles = Base_pb2.ConstrainedJointAngles()  # 创建约束关节角度对象
        actuator_count = self.base.GetActuatorCount().count           # 获取执行器数量
        
        angles = [0.0] * actuator_count  # 所有关节角度设为0度

        # 为每个关节设置目标角度
        for joint_id in range(len(angles)):
            joint_angle = constrained_joint_angles.joint_angles.joint_angles.add()  # 添加关节角度
            joint_angle.joint_identifier = joint_id  # 设置关节ID
            joint_angle.value = angles[joint_id]     # 设置角度值

        # 事件同步逻辑
        finished_event = threading.Event()  # 创建完成事件

        def check_for_end_or_abort(notification, event=finished_event):
            """检查动作是否结束或中止"""
            if notification.action_event == Base_pb2.ACTION_END or notification.action_event == Base_pb2.ACTION_ABORT:
                event.set()  # 设置事件完成标志

        # 订阅动作通知
        notification_handle = self.base.OnNotificationActionTopic(
            check_for_end_or_abort,         # 回调函数
            Base_pb2.NotificationOptions()  # 通知选项
        )

        print("Reaching joint angles...")  # 打印状态信息
        self.base.PlayJointTrajectory(constrained_joint_angles)  # 执行关节轨迹

        print("Waiting for movement to finish ...")  # 等待运动完成
        finished = finished_event.wait(self.run_duration)  # 等待完成事件，最长等待run_duration秒
        self.base.Unsubscribe(notification_handle)         # 取消订阅通知

        if finished:
            print("Joint angles reached")    # 成功到达目标角度
        else:
            print("Timeout on action notification wait")  # 等待超时
        return finished  # 返回是否成功

    def InitTorqueControl(self):
        """初始化力矩控制模式"""
        # 移动到起始位置以确保安全
        if not self.example_move_to_start_position():
            return False  # 如果移动失败，返回False

        # 初次刷新获取反馈
        self.base_feedback = self.base_cyclic.RefreshFeedback()  # 刷新反馈数据

        # 为所有执行器启用伺服并设置初始位置
        for i in range(self.actuator_count):
            self.base_command.actuators[i].flags = 1  # 启用伺服控制
            self.base_command.actuators[i].position = self.base_feedback.actuators[i].position  # 设置当前位置为目标位置

        # 力矩控制只作用于指定的执行器
        self.base_command.actuators[self.control_axis_index].torque_joint = 0.0  # 初始力矩命令设为0

        # 设置臂为低级伺服模式
        base_servo_mode = Base_pb2.ServoingModeInformation()               # 创建伺服模式信息
        base_servo_mode.servoing_mode = Base_pb2.LOW_LEVEL_SERVOING        # 设置为低级伺服模式
        self.base.SetServoingMode(base_servo_mode)                         # 应用伺服模式

        # 发送首个命令帧
        self.base_feedback = self.base_cyclic.Refresh(self.base_command, 0, self.sendOption)  # 发送命令并获取反馈

        # 指定执行器切换为力矩控制模式
        control_mode_msg = ActuatorConfig_pb2.ControlModeInformation()      # 创建控制模式信息
        control_mode_msg.control_mode = ActuatorConfig_pb2.ControlMode.TORQUE  # 设置为力矩控制模式
        self.actuator_config.SetControlMode(control_mode_msg, self.control_device_id)  # 应用控制模式

        print(f"✅ 第 {self.CONTROL_AXIS} 轴已切换到力矩控制模式")
        return True  # 初始化成功

    def StartTorqueControl(self):
        """启动力矩控制线程"""
        if self.thread and self.thread.is_alive():  # 检查线程是否已经在运行
            print("Control is already running")
            return
        
        # 🆕 启动前重置角度连续性处理器
        self.angle_unwrapper.reset()
        
        print(f"Starting torque control on axis {self.CONTROL_AXIS}...")  # 打印启动信息
        self.control_active = True   # 设置控制激活标志
        self.kill_thread = False     # 清除线程终止标志
        self.thread = threading.Thread(target=self.RunTorqueLoop)  # 创建控制线程
        self.thread.start()          # 启动线程

    def RunTorqueLoop(self):
        """力矩控制主循环，包含数据记录功能"""
        print(f"Running torque control for {self.run_duration} seconds...")  # 打印运行信息
        start_time = time.time()  # 记录开始时间
        frame_id = 0              # 初始化帧ID

        # 主控制循环
        while not self.kill_thread and (time.time() - start_time) < self.run_duration:
            loop_time = time.time() - start_time  # 计算循环时间

            # 🆕 获取连续的位置角度（处理360度跳跃）
            position_deg, raw_position_deg = self.get_continuous_position()
            
            # 获取速度反馈（度/秒）
            velocity_deg_per_sec = self.base_feedback.actuators[self.control_axis_index].velocity

            # 转换为弧度单位
            position_rad         = position_deg * math.pi / 180.0      # 位置转换为弧度
            velocity_rad_per_sec = velocity_deg_per_sec * math.pi / 180.0     # 速度转换为弧度/秒

            # --------------------------------------------------
            # 1) 使用统一的轨迹生成方法计算目标位置和速度
            desired_rad, desired_vel = self.compute_desired_trajectory(loop_time)

            # 2) 计算误差：当前值减去目标值
            position_error = position_rad - desired_rad         # 位置误差
            velocity_error = velocity_rad_per_sec - desired_vel  # 速度误差

            # 3) 调用控制律计算力矩输出
            self.torque_value = self.controller.control_law(position_error, velocity_error)
            # --------------------------------------------------

            # 限制输出力矩范围
            self.torque_value = max(min(self.torque_value, 20.0), -20.0)  # 限制在[-20, 20]牛米

            # 记录数据用于后续分析
            self.time_history.append(loop_time)                 # 记录时间
            self.position_history.append(position_rad)          # 记录连续的实际位置
            self.torque_history.append(self.torque_value)       # 记录力矩
            self.desired_history.append(desired_rad)            # 记录期望位置
            self.raw_position_history.append(raw_position_deg)  # 🆕 记录原始位置（用于调试）

            # 设置命令：控制轴使用力矩控制，其他轴保持位置
            # 注意：这里使用原始位置进行命令设置，因为机器人API期望的是原始角度
            self.base_command.actuators[self.control_axis_index].position     = raw_position_deg   # 设置控制轴位置
            self.base_command.actuators[self.control_axis_index].torque_joint = self.torque_value  # 设置控制轴力矩
            
            # 保持其他轴的位置不变
            for i in range(self.actuator_count):
                if i != self.control_axis_index:  # 非控制轴
                    self.base_command.actuators[i].position = self.base_feedback.actuators[i].position  # 保持当前位置

            # 更新帧ID和命令ID
            frame_id = (frame_id + 1) % 65536           # 循环更新帧ID，防止溢出
            self.base_command.frame_id = frame_id       # 设置命令帧ID
            for i in range(self.actuator_count):
                self.base_command.actuators[i].command_id = frame_id  # 设置每个执行器的命令ID

            # 发送命令并获取反馈
            try:
                self.base_feedback = self.base_cyclic.Refresh(self.base_command, 0, self.sendOption)  # 发送命令
            except Exception as err:
                print(f"Warning: failed sending command: {err}")  # 打印发送失败警告

            time.sleep(0.001)  # 休眠1毫秒，控制循环周期

        print("Torque control loop finished.")  # 控制循环结束
        self.control_active = False              # 清除控制激活标志

    def Stop(self):
        """停止力矩控制并恢复位置模式"""
        print(f"Stopping torque control on axis {self.CONTROL_AXIS} and restoring position mode...")  # 打印停止信息
        self.kill_thread = True      # 设置线程终止标志
        self.control_active = False  # 清除控制激活标志
        
        if self.thread:              # 如果线程存在
            self.thread.join()       # 等待线程结束

        # 指定执行器切回位置控制模式
        control_mode_msg = ActuatorConfig_pb2.ControlModeInformation()           # 创建控制模式信息
        control_mode_msg.control_mode = ActuatorConfig_pb2.ControlMode.POSITION  # 设置为位置控制模式
        self.actuator_config.SetControlMode(control_mode_msg, self.control_device_id)  # 应用控制模式

        # 臂切回单级伺服（默认模式）
        base_servo_mode = Base_pb2.ServoingModeInformation()          # 创建伺服模式信息
        base_servo_mode.servoing_mode = Base_pb2.SINGLE_LEVEL_SERVOING  # 设置为单级伺服模式
        self.base.SetServoingMode(base_servo_mode)                    # 应用伺服模式

        print(f"✅ 第 {self.CONTROL_AXIS} 轴已恢复位置控制模式")  # 打印恢复成功信息
        print("Clean exit done.")                                  # 打印清理完成信息
        self.save_and_plot()                                       # 绘制图表
        
    def save_and_plot(self):
        """绘制关节角度跟踪误差图和控制力矩图"""
        if not self.time_history:  # 检查是否有数据
            print("❌ 没有数据可绘制")
            return
            
        # 转成 numpy 数组
        t           = np.array(self.time_history)        # 时间数组
        pos         = np.array(self.position_history)    # 连续位置数组（弧度）
        torque      = np.array(self.torque_history)      # 控制力矩数组（牛米）
        raw_pos_deg = np.array(self.raw_position_history)  # 🆕 原始位置数组（度）
        
        # 方法1: 使用记录的期望轨迹（推荐，避免重复计算）
        desired_pos = np.array(self.desired_history)  # 使用记录的期望位置
        
        # 方法2: 如果没有记录期望轨迹，可以重新计算（与控制循环完全一致）
        if len(self.desired_history) == 0:
            print("⚠️  期望轨迹未记录，正在重新计算...")
            desired_pos, _ = self.compute_desired_trajectory(t)
        
        # 计算位置跟踪误差
        pos_error = pos - desired_pos            # 位置跟踪误差

        # 🆕 创建包含原始角度对比的图形窗口
        plt.figure(figsize=(16,15))

        # 第一个子图：原始角度 vs 连续角度对比
        plt.subplot(4,1,1)
        plt.plot(t, raw_pos_deg, 'r-', linewidth=1, alpha=0.7, label="Raw Angle (with jumps)")  # 原始角度
        plt.plot(t, np.degrees(pos) + 180, 'b-', linewidth=1.5, label="Continuous Angle")       # 连续角度
        plt.title(f"Joint {self.CONTROL_AXIS} Angle Unwrapping Comparison", fontsize=14, fontweight='bold')
        plt.xlabel("Time (s)", fontsize=12)
        plt.ylabel("Position (degrees)", fontsize=12)
        plt.legend(fontsize=11)
        plt.grid(True, alpha=0.3)

         # 第二个子图：位置跟踪对比
        plt.subplot(4,1,2)
        plt.plot(t, np.degrees(pos), 'b-', linewidth=1.5, label="Actual Position")      # 实际位置
        plt.plot(t, np.degrees(desired_pos), 'r--', linewidth=1.5, label="Desired Position")  # 期望位置
        plt.title(f"Joint {self.CONTROL_AXIS} Position Tracking (Amplitude: {self.amplitude_deg}°, Frequency: {self.frequency_hz}Hz)", 
                 fontsize=14, fontweight='bold')
        plt.xlabel("Time (s)", fontsize=12)
        plt.ylabel("Position (degrees)", fontsize=12)
        plt.legend(fontsize=11)
        plt.grid(True, alpha=0.3)

        # 第三个子图：位置跟踪误差
        plt.subplot(4,1,3)
        plt.plot(t, np.degrees(pos_error), 'g-', linewidth=1.5, label="Position Error")  # 位置误差（度）
        plt.title(f"Joint {self.CONTROL_AXIS} Position Tracking Error", fontsize=14, fontweight='bold')
        plt.xlabel("Time (s)", fontsize=12)
        plt.ylabel("Error (degrees)", fontsize=12)
        plt.legend(fontsize=11)
        plt.grid(True, alpha=0.3)

        # 第四个子图：控制力矩
        plt.subplot(4,1,4)
        plt.plot(t, torque, 'm-', linewidth=1.5, label="Control Torque")  # 控制力矩
        plt.title(f"Joint {self.CONTROL_AXIS} Control Torque", fontsize=14, fontweight='bold')
        plt.xlabel("Time (s)", fontsize=12)
        plt.ylabel("Torque (Nm)", fontsize=12)
        plt.legend(fontsize=11)
        plt.grid(True, alpha=0.3)
        
        # 调整子图间距，防止重叠
        plt.tight_layout(pad=2.0)
        
        # 保存图片文件
        plot_filename = f"torque_control_axis{self.CONTROL_AXIS}_results_with_unwrapping.png"
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        print(f"✅ 绘图已保存至 {plot_filename}")
        
        # 计算并打印统计信息
        rms_error = np.sqrt(np.mean(pos_error**2))
        max_error = np.max(np.abs(pos_error))
        mean_torque = np.mean(np.abs(torque))
        max_torque = np.max(np.abs(torque))
        
        # 🆕 计算角度跳跃统计
        jump_count = abs(self.angle_unwrapper.cumulative_offset) / 360.0
        
        print(f"📊 跟踪性能统计:")
        print(f"   RMS误差: {np.degrees(rms_error):.3f}°")
        print(f"   最大误差: {np.degrees(max_error):.3f}°")
        print(f"   平均力矩: {mean_torque:.3f} Nm")
        print(f"   最大力矩: {max_torque:.3f} Nm")
        print(f"🔄 角度连续性统计:")
        print(f"   总跳跃圈数: {jump_count:.1f} 圈")
        print(f"   累积偏移: {self.angle_unwrapper.cumulative_offset:.1f}°")

def main():
    """主函数"""
    import argparse  # 命令行参数解析
    # 加入utilities路径，根据实际调整
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))  # 添加utilities路径到系统路径
    import utilities  # 导入utilities模块

    parser = argparse.ArgumentParser()                    # 创建参数解析器
    args = utilities.parseConnectionArguments(parser)     # 解析连接参数

    # 建立TCP和UDP连接
    with utilities.DeviceConnection.createTcpConnection(args) as router:           # 创建TCP连接
        with utilities.DeviceConnection.createUdpConnection(args) as router_real_time:  # 创建UDP实时连接
            torque_ctrl = TorqueControlSingle(router, router_real_time)  # 创建力矩控制器实例

            if torque_ctrl.InitTorqueControl():  # 初始化力矩控制
                try:
                    print("Initialization complete. Press 's' to start torque control for 20 seconds.")  # 打印初始化完成信息
                    print("Press 'q' to quit.")  # 打印退出提示
                    
                    while True:  # 主循环
                        # 检查用户输入
                        if select.select([sys.stdin], [], [], 0.1)[0]:  # 检查是否有键盘输入
                            key = sys.stdin.readline().strip().lower()  # 读取输入并转换为小写
                            
                            if key == 's' and not torque_ctrl.control_active:  # 如果输入's'且控制未激活
                                torque_ctrl.StartTorqueControl()  # 启动力矩控制
                                print(f"Torque control started on axis {torque_ctrl.CONTROL_AXIS}. Running for 20 seconds...")  # 打印启动信息
                                
                            elif key == 'q':  # 如果输入'q'
                                print("Quitting...")  # 打印退出信息
                                break  # 退出循环
                        
                        # 如果控制正在运行，检查是否完成
                        if torque_ctrl.control_active and not torque_ctrl.thread.is_alive():  # 如果控制激活但线程已结束
                            print("Torque control completed.")  # 打印控制完成信息
                            
                except KeyboardInterrupt:  # 捕获键盘中断
                    print("Interrupted by user")  # 打印用户中断信息
                finally:
                    torque_ctrl.Stop()  # 停止控制器
                return 0  # 返回成功状态码
            else:
                print("Initialization failed")  # 打印初始化失败信息
                return 1  # 返回失败状态码

if __name__ == "__main__":
    sys.exit(main())  # 执行主函数并退出程序